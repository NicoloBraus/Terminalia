from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx'); s=p.read_text(); s=s.replace(', runNativeSafeCommand, runStructuredCommand', ', runStructuredCommand', 1); p.write_text(s); print('legacy import removed')
