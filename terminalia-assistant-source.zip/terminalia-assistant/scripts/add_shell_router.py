from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/src-tauri/src/main.rs'); s=p.read_text()
s=s.replace('#[derive(Debug, Serialize)] struct CommandResult { command: String, stdout: String, stderr: String, exit_code: i32, working_directory: String }', '#[derive(Debug, Serialize)] struct CommandResult { shell: String, command: String, stdout: String, stderr: String, exit_code: i32, working_directory: String }')
start=s.index('fn is_allowed_read_command')
end=s.index('\n#[tauri::command]\nfn choose_models_directory', start)
new=r'''#[derive(Debug, Clone, Copy, PartialEq, Eq)] enum ShellKind { PowerShell, Cmd, Direct }
impl ShellKind { fn as_str(self) -> &'static str { match self { Self::PowerShell => "powershell", Self::Cmd => "cmd", Self::Direct => "direct" } } }
fn parse_shell(value: &str) -> Result<ShellKind, String> { match value { "powershell" => Ok(ShellKind::PowerShell), "cmd" => Ok(ShellKind::Cmd), "direct" => Ok(ShellKind::Direct), _ => Err("Shell inválido. Use powershell, cmd ou direct.".into()) } }
fn is_allowed_command(shell: ShellKind, command: &str) -> bool { match shell { ShellKind::PowerShell => matches!(command.trim(), "Get-Location" | "Get-ChildItem" | "whoami" | "git status"), ShellKind::Cmd => matches!(command.trim(), "ipconfig /all" | "ipconfig" | "tasklist" | "where" | "whoami"), ShellKind::Direct => matches!(command.trim(), "git --version" | "python --version" | "node --version" | "pnpm --version" | "cargo --version") } }
fn execute_structured(shell: ShellKind, normalized: &str, state: &State<'_, AppState>) -> Result<CommandResult, String> {
    if !is_allowed_command(shell, normalized) { return Err(format!("Comando fora da allowlist de {}. Nenhum processo foi iniciado.", shell.as_str())); }
    let configured_dir = state.inner().working_directory.lock().map_err(|_| "Falha ao ler diretório de trabalho".to_string())?;
    let mut process = match shell { ShellKind::PowerShell => { let mut p = Command::new("powershell.exe"); p.args(["-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "RemoteSigned", "-Command", normalized]); p }, ShellKind::Cmd => { let mut p = Command::new("cmd.exe"); p.args(["/D", "/S", "/C", normalized]); p }, ShellKind::Direct => { let mut parts = normalized.split_whitespace(); let program = parts.next().ok_or_else(|| "Comando vazio".to_string())?; let mut p = Command::new(program); p.args(parts); p } };
    if let Some(directory) = configured_dir.as_deref() { process.current_dir(directory); }
    let output = process.output().map_err(|error| format!("Não foi possível iniciar {}: {error}", shell.as_str()))?;
    Ok(CommandResult { shell: shell.as_str().into(), command: normalized.into(), stdout: String::from_utf8_lossy(&output.stdout).trim().into(), stderr: String::from_utf8_lossy(&output.stderr).trim().into(), exit_code: output.status.code().unwrap_or(-1), working_directory: std::env::current_dir().map_err(|error| error.to_string())?.display().to_string() })
}
#[tauri::command]
fn run_structured_command(shell: String, command: String, state: State<'_, AppState>) -> Result<CommandResult, String> { let kind = parse_shell(&shell)?; let normalized = command.trim().to_string(); if normalized.is_empty() { return Err("Comando vazio".into()); } execute_structured(kind, &normalized, &state) }
#[tauri::command]
fn run_safe_command(command: String, state: State<'_, AppState>) -> Result<CommandResult, String> { run_structured_command("powershell".into(), command, state) }
'''
s=s[:start]+new+s[end:]
s=s.replace('generate_local_text]).run', 'generate_local_text, run_structured_command]).run')
p.write_text(s); print('shell router added')
