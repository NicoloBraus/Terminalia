from pathlib import Path
import re
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx'); s=p.read_text()
# Clean hidden reasoning blocks before showing or interpreting model output.
marker='function Workspace({ initialPrompt,'
clean='''function cleanModelText(text: string) { return text.replace(/<think>[\\s\\S]*?<\\/think>/gi, "").replace(/<\\|think_start\\|>[\\s\\S]*?<\\|think_end\\|>/gi, "").trim(); }\n'''
if 'function cleanModelText' not in s: s=s.replace(marker, clean+marker,1)
s=s.replace('const action = result.text.match(/^ACTION:', 'const answerText = cleanModelText(result.text); const action = answerText.match(/^ACTION:',1)
s=s.replace('} else { if (!result.text.trim()) throw new Error("O motor local respondeu sem texto. Verifique se o GGUF carregado é compatível com o chat template e tente o teste: Responda somente com OK."); showResponse(result.text); }', '} else { if (!answerText) throw new Error("O motor local respondeu sem texto. Verifique se o GGUF carregado é compatível com o chat template e tente o teste: Responda somente com OK."); showResponse(answerText); }',1)
# Make the command history list scroll within the modal.
s=s.replace('<div className="mt-4 grid gap-4 md:grid-cols-[1fr_1.05fr]"><div className="space-y-2">{filtered.map', '<div className="mt-4 grid gap-4 md:grid-cols-[1fr_1.05fr]"><div className="max-h-[55vh] min-h-0 space-y-2 overflow-y-auto pr-1">{filtered.map',1)
# Replace chat history cards with a card plus a delete control.
old='<div className="mt-5 flex-1 space-y-2 overflow-y-auto">{chatSessions.length ? chatSessions.map((session) => <button key={session.id} onClick={() => openSavedChat(session)} className="w-full rounded-xl border border-white/[.08] bg-[#151b1b] p-3 text-left hover:border-[#f28b4b]/30"><p className="truncate text-[11px] font-semibold text-[#ded4cc]">{session.title}</p><p className="mt-1 text-[9px] text-[#746b64]">{session.messages.length} mensagens</p></button>) :'
new='<div className="mt-5 flex-1 space-y-2 overflow-y-auto">{chatSessions.length ? chatSessions.map((session) => <div key={session.id} className="flex items-center gap-2 rounded-xl border border-white/[.08] bg-[#151b1b] p-2 hover:border-[#f28b4b]/30"><button onClick={() => openSavedChat(session)} className="min-w-0 flex-1 p-1 text-left"><p className="truncate text-[11px] font-semibold text-[#ded4cc]">{session.title}</p><p className="mt-1 text-[9px] text-[#746b64]">{session.messages.length} mensagens</p></button><button onClick={(event) => { event.stopPropagation(); const next = chatSessions.filter((item) => item.id !== session.id); setChatSessions(next); localStorage.setItem("terminalia-chat-sessions", JSON.stringify(next)); }} className="rounded-lg p-2 text-[#81766e] hover:bg-rose-400/10 hover:text-rose-300" title="Apagar conversa"><Trash2 size={13} /></button></div>) :'
if old not in s: raise SystemExit('chat history cards not found')
s=s.replace(old,new,1)
# Prefer last successfully loaded model when initializing settings.
s=s.replace('localStorage.getItem("terminalia-model-path") ?? localStorage.getItem("terminalia-model") ?? ""', 'localStorage.getItem("terminalia-last-model-path") ?? localStorage.getItem("terminalia-model-path") ?? localStorage.getItem("terminalia-model") ?? ""',1)
s=s.replace('const saved = localStorage.getItem("terminalia-model-path");', 'const saved = localStorage.getItem("terminalia-last-model-path") ?? localStorage.getItem("terminalia-model-path");',1)
# Persist last model on every explicit selection and successful load.
s=s.replace('localStorage.setItem("terminalia-model-path", event.target.value); localStorage.setItem("terminalia-model", event.target.value);', 'localStorage.setItem("terminalia-model-path", event.target.value); localStorage.setItem("terminalia-last-model-path", event.target.value); localStorage.setItem("terminalia-model", event.target.value);',1)
s=s.replace('localStorage.setItem("terminalia-model-path", selected.path); setMessage(result.message);', 'localStorage.setItem("terminalia-model-path", selected.path); localStorage.setItem("terminalia-last-model-path", selected.path); localStorage.setItem("terminalia-model", selected.path); setMessage(result.message);',1)
# The automatic initial loader also prefers the last loaded path.
s=s.replace('const savedModel = localStorage.getItem("terminalia-model-path") ?? "";', 'const savedModel = localStorage.getItem("terminalia-last-model-path") ?? localStorage.getItem("terminalia-model-path") ?? "";',1)
p.write_text(s); print('history, think filter and last model persistence applied')
