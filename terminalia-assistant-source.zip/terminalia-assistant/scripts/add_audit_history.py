from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx')
s=p.read_text()
marker='function TerminalPanel() {'
helper='''type AuditStatus = "executed" | "review" | "authorized" | "cancelled" | "blocked";
function recordAudit(command: string, status: AuditStatus, mode = "balanced") {
  const previous = JSON.parse(localStorage.getItem("terminalia-audit-log") ?? "[]");
  const entry = { id: `${Date.now()}-${Math.random()}`, command, status, mode, time: new Date().toLocaleString("pt-BR"), detail: status === "executed" ? "executado automaticamente" : status === "review" ? "aguardando aprovação" : status === "authorized" ? "autorizado após confirmação reforçada" : status === "cancelled" ? "cancelado pelo usuário" : "bloqueado pela política" };
  localStorage.setItem("terminalia-audit-log", JSON.stringify([entry, ...previous].slice(0, 100)));
  window.dispatchEvent(new CustomEvent("terminalia-audit-update"));
}
'''
s=s.replace(marker, helper+marker, 1)
s=s.replace('if (risk === "blocked") { setDangerCommand(current);', 'if (risk === "blocked") { recordAudit(current, "blocked", securityMode); setDangerCommand(current);', 1)
s=s.replace('if (risk === "review") { setNotice(', 'if (risk === "review") { recordAudit(current, "review", securityMode); setNotice(', 1)
s=s.replace('setLines((prev) => [...prev, `PS> ${current}`, "Executando com política de segurança...", "✓ comando concluído sem elevação"]);', 'recordAudit(current, "executed", securityMode); setLines((prev) => [...prev, `PS> ${current}`, "Executando com política de segurança...", "✓ comando concluído sem elevação"]);', 1)
s=s.replace('const continueDanger = () => { if (dangerStep < 4)', 'const continueDanger = () => { if (dangerStep < 4)', 1)
s=s.replace('setLines((prev) => [...prev, `PS> ${dangerCommand}`, "⚠ execução autorizada após confirmação reforçada",', 'recordAudit(dangerCommand, "authorized", securityMode); setLines((prev) => [...prev, `PS> ${dangerCommand}`, "⚠ execução autorizada após confirmação reforçada",', 1)
s=s.replace('const cancelDanger = () => { setLines', 'const cancelDanger = () => { recordAudit(dangerCommand, "cancelled", securityMode); setLines', 1)
needle='  const [filter, setFilter] = useState("todas");\n'
state='  const [audit, setAudit] = useState<any[]>(() => JSON.parse(localStorage.getItem("terminalia-audit-log") ?? "[]"));\n  useEffect(() => { const refresh = () => setAudit(JSON.parse(localStorage.getItem("terminalia-audit-log") ?? "[]")); window.addEventListener("terminalia-audit-update", refresh); return () => window.removeEventListener("terminalia-audit-update", refresh); }, []);\n'
s=s.replace(needle, needle+state, 1)
needle2='  const filtered = history.filter((item) =>'
addition='  const auditHistory = audit.map((item) => ({ id: item.id, title: `Comando: ${item.command}`, status: item.status === "executed" || item.status === "authorized" ? "Concluída" : item.status === "review" ? "Aguardando aprovação" : item.status === "cancelled" ? "Cancelada" : "Bloqueada", tone: item.status === "executed" || item.status === "authorized" ? "done" : item.status === "review" ? "paused" : "paused", time: item.time, duration: "local", tools: ["Terminal"], command: item.command, detail: `${item.detail} · modo ${item.mode}` }));\n'
s=s.replace(needle2, addition+needle2.replace('history.filter', '(auditHistory.length ? auditHistory : history).filter'), 1)
p.write_text(s)
print('audit added')
