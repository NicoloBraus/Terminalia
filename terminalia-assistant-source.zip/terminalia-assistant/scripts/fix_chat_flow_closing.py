from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx'); s=p.read_text()
old='</aside></div></div>{approvalOpen && <ApprovalPanel onApprove={() => setApprovalOpen(false)} onDeny={() => setApprovalOpen(false)} />}</div>; }'
new='</aside></div>{approvalOpen && <ApprovalPanel onApprove={() => setApprovalOpen(false)} onDeny={() => setApprovalOpen(false)} />}</div>; }'
if old not in s: raise SystemExit('closing sequence not found')
p.write_text(s.replace(old,new,1)); print('jsx closing fixed')
