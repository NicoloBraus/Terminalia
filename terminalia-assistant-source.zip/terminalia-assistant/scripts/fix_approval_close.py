from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx')
s=p.read_text()
s=s.replace('</aside></div></div></div>{approvalOpen && <ApprovalPanel', '</aside></div></div>{approvalOpen && <ApprovalPanel', 1)
p.write_text(s)
print('fixed')
