from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx'); s=p.read_text(); s=s.replace('Layers3, Menu, MessageSquare', 'Layers3, Menu, MessageSquare, Minus', 1); p.write_text(s); print('Minus import added')
