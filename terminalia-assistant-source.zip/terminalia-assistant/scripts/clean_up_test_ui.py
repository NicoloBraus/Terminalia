from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx')
s=p.read_text()
old='const current = sourceHistory.find((item) => item.id === selected) ?? sourceHistory[0];'
new='const current = sourceHistory.find((item) => item.id === selected) ?? sourceHistory[0] ?? { title: "Nenhuma execução registrada", time: "agora", duration: "00:00", command: "—", detail: "O histórico está limpo" };'
if old not in s: raise SystemExit('empty history fallback not found')
s=s.replace(old,new,1)
p.write_text(s)
print('empty history fallback added')
