from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/src-tauri/src/main.rs'); s=p.read_text()
insert=r'''
#[tauri::command]
fn write_obsidian_note(directory: String, title: String, content: String) -> Result<String, String> { let root=PathBuf::from(directory.trim()); if !root.is_dir() { return Err("Vault não encontrado".into()); } let clean=title.trim().chars().filter(|c| c.is_alphanumeric() || *c==' ' || *c=='-' || *c=='_').collect::<String>(); if clean.is_empty() { return Err("Título inválido".into()); } let path=root.join(format!("{clean}.md")); std::fs::write(&path, content.chars().take(40_000).collect::<String>()).map_err(|e| format!("Falha ao salvar nota: {e}"))?; Ok(path.display().to_string()) }
'''
needle='#[tauri::command] fn get_bridge_status'
s=s.replace(needle,insert+'\n'+needle,1)
s=s.replace('read_obsidian_context]', 'read_obsidian_context, write_obsidian_note]',1)
p.write_text(s); print('learning note command added')
