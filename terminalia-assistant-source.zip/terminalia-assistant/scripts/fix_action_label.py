from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx'); s=p.read_text(); s=s.replace('command={`Excluir atalho "${actionName}" da Área de Trabalho`}', 'command={actionName}', 1); p.write_text(s); print('action label fixed')
