from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx'); s=p.read_text(); s=s.replace('runNativeSafeCommand(command)', 'runStructuredCommand(command === "whoami" ? "cmd" : "powershell", command)', 1); p.write_text(s); print('bridge test routed')
