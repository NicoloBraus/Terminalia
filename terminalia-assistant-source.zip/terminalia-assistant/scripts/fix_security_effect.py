from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx')
s=p.read_text()
e='  useEffect(() => { const sync = (event: Event) => setSecurityMode((event as CustomEvent<string>).detail); window.addEventListener("terminalia-security-change", sync); return () => window.removeEventListener("terminalia-security-change", sync); }, []);\n'
s=s.replace(e,'',1)
needle='  const [notice, setNotice] = useState("");\n'
s=s.replace(needle, needle+e, 1)
p.write_text(s)
print('effect fixed')
