from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/src-tauri/src/main.rs')
s=p.read_text()
old='let target = PathBuf::from(path.trim()); validate_user_path(&target)?;'
new='let raw_path = path.trim(); let profile = user_profile_path()?; let target = if let Some(rest) = raw_path.strip_prefix("desktop:") { profile.join("Desktop").join(rest.trim_start_matches([\\\\, \'/\'])) } else if let Some(rest) = raw_path.strip_prefix("home:") { profile.join(rest.trim_start_matches([\\\\, \'/\'])) } else { PathBuf::from(raw_path) }; validate_user_path(&target)?;'
if old not in s: raise SystemExit('path target not found')
s=s.replace(old,new,1)
p.write_text(s)
print('path aliases added')
