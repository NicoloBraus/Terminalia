$ErrorActionPreference = "Stop"
Write-Host "Terminalia - diagnóstico llama-server local" -ForegroundColor Cyan
$server = Get-Command llama-server.exe -ErrorAction SilentlyContinue
if (-not $server) { Write-Warning "llama-server.exe não foi encontrado no PATH."; Write-Host "Coloque llama-server.exe e as DLLs ao lado do Terminalia.exe ou adicione a pasta ao PATH."; exit 2 }
Write-Host "llama-server: $($server.Source)" -ForegroundColor Green
$models = Get-ChildItem -Path (Read-Host "Pasta dos modelos GGUF") -Filter *.gguf -File
if (-not $models) { throw "Nenhum arquivo GGUF encontrado." }
$models | ForEach-Object { $kind = if ($_.Name -match 'mmproj|vision-projector|multimodal-projector') { 'projetor multimodal' } else { 'modelo principal' }; Write-Host "$kind - $($_.Name) - $([math]::Round($_.Length/1GB,2)) GB" }
Write-Host "Teste concluído. O Terminalia usará 127.0.0.1:39200." -ForegroundColor Green
