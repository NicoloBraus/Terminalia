from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx'); s=p.read_text()
a=s.index('function Workspace('); b=s.index('useEffect(() => { if (initialPrompt.trim())',a); part=s[a:b]
part=part.replace('const [submittedMessages, setSubmittedMessages] = useState<string[]>([]);', 'const [submittedMessages, setSubmittedMessages] = useState<string[]>([]); const [conversation, setConversation] = useState<{ role: "user" | "assistant"; text: string }[]>([]);',1)
marker='const currentTool = tools.find((tool) => tool.id === active)!; '
part=part.replace(marker, marker+'const showResponse = (text: string) => { setResponse(text); setConversation((items) => [...items, { role: "assistant", text }]); }; ',1)
# All response updates in the action/generation logic become historical assistant messages.
part=part.replace('setResponse(', 'showResponse(')
# Restore the helper's internal state update, which was changed by the broad replacement.
part=part.replace('const showResponse = (text: string) => { showResponse(text);', 'const showResponse = (text: string) => { setResponse(text);',1)
part=part.replace('setMessage(""); setSubmittedMessages((items) => [...items, prompt]);', 'setMessage(""); setSubmittedMessages((items) => [...items, prompt]); setConversation((items) => [...items, { role: "user", text: prompt }]);',1)
s=s[:a]+part+s[b:]
old='{response && <div className="flex gap-3"><div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#f28b4b] text-[#211109]"><Bot size={16} /></div><div className="max-w-[700px] rounded-2xl rounded-tl-md border border-white/[.08] bg-[#151b1b] px-4 py-3.5 text-[12px] leading-6 text-[#b8b0a9] whitespace-pre-wrap">{response}</div></div>}'
new='{conversation.filter((item) => item.role === "assistant").map((item, index) => <div key={`assistant-${index}`} className="flex gap-3"><div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#f28b4b] text-[#211109]"><Bot size={16} /></div><div className="max-w-[700px] rounded-2xl rounded-tl-md border border-white/[.08] bg-[#151b1b] px-4 py-3.5 text-[12px] leading-6 text-[#b8b0a9] whitespace-pre-wrap">{item.text}</div></div>)}'
if old not in s: raise SystemExit('response JSX not found')
s=s.replace(old,new,1)
p.write_text(s); print('chat history persisted in session')
