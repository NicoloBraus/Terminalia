from pathlib import Path
import re
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx'); s=p.read_text()
# Remove automatic loading of the previous current-chat transcript. Saved chats are opened explicitly from History.
s,n=re.subn(r'useEffect\(\(\) => \{ const saved = localStorage\.getItem\("terminalia-chat-history"\);.*?\}, \[\]\); ', '', s, count=1)
if n!=1: raise SystemExit(f'current chat hydration effect not found: {n}')
# Do not append an empty assistant bubble before generation.
s=s.replace('setGenerating(true); showResponse(""); try {', 'setGenerating(true); try {',1)
p.write_text(s); print('new session isolation applied')

p=Path('client/src/lib/nativeBridge.ts'); s=p.read_text()
old='return { text: data.choices?.[0]?.message?.content ?? "", model_path: "llama-server", tokens: 0 }; }'
new='const content = data.choices?.[0]?.message?.content?.trim() ?? ""; if (!content) throw new Error("llama-server respondeu sem conteúdo. Verifique se o GGUF carregado é compatível com o chat template."); return { text: content, model_path: "llama-server", tokens: 0 }; }'
if old not in s: raise SystemExit('empty server response return not found')
s=s.replace(old,new,1); p.write_text(s); print('empty server response made explicit error')
