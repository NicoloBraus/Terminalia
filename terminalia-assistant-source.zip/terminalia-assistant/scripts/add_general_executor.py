from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/src-tauri/src/main.rs'); s=p.read_text()
insert=r'''
fn command_is_restricted(command: &str) -> bool { let c=command.to_ascii_lowercase(); c.contains("remove-item") || c.contains("del ") || c.contains("format-") || c.contains("diskpart") || c.contains("reg delete") || c.contains("shutdown") || c.contains("start-process") && c.contains("runas") || c.contains("clear-disk") || c.contains("git push") }
fn execute_general(shell: ShellKind, command: &str, state: &State<'_, AppState>) -> Result<CommandResult, String> {
    let configured_dir = state.inner().working_directory.lock().map_err(|_| "Falha ao ler diretório de trabalho".to_string())?;
    let mut process = match shell { ShellKind::PowerShell => { let mut p=Command::new("powershell.exe"); p.args(["-NoLogo","-NoProfile","-NonInteractive","-ExecutionPolicy","RemoteSigned","-Command",command]); p }, ShellKind::Cmd => { let mut p=Command::new("cmd.exe"); p.args(["/D","/S","/C",command]); p }, ShellKind::Direct => { let mut parts=command.split_whitespace(); let program=parts.next().ok_or_else(|| "Comando vazio".to_string())?; let mut p=Command::new(program); p.args(parts); p } };
    if let Some(directory)=configured_dir.as_deref() { process.current_dir(directory); }
    let output=process.output().map_err(|e| format!("Não foi possível iniciar {}: {e}", shell.as_str()))?;
    Ok(CommandResult { shell:shell.as_str().into(), command:command.into(), stdout:String::from_utf8_lossy(&output.stdout).trim().into(), stderr:String::from_utf8_lossy(&output.stderr).trim().into(), exit_code:output.status.code().unwrap_or(-1), working_directory:std::env::current_dir().map_err(|e| e.to_string())?.display().to_string() })
}
#[tauri::command]
fn run_general_command(shell: String, command: String, confirmed: bool, state: State<'_, AppState>) -> Result<CommandResult, String> { let kind=parse_shell(&shell)?; let normalized=command.trim().to_string(); if normalized.is_empty() { return Err("Comando vazio".into()); } if command_is_restricted(&normalized) && !confirmed { return Err("Este comando exige confirmação reforçada antes da execução".into()); } execute_general(kind, &normalized, &state) }
'''
needle='#[derive(Debug, Serialize)] struct ShortcutDeleteResult'
s=s.replace(needle,insert+'\n'+needle,1)
s=s.replace('run_structured_command, delete_desktop_shortcut', 'run_structured_command, run_general_command, delete_desktop_shortcut',1)
p.write_text(s); print('general executor added')
