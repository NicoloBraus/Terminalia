from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/src-tauri/src/main.rs'); s=p.read_text()
insert=r'''
#[derive(Debug, Serialize)] struct WebFetchResult { url: String, title: String, content: String, status: i32 }
#[tauri::command]
fn fetch_web_page(url: String) -> Result<WebFetchResult, String> {
    let clean = url.trim().to_string(); if !(clean.starts_with("https://") || clean.starts_with("http://")) { return Err("A URL precisa começar com http:// ou https://".into()); } if clean.contains("localhost") || clean.contains("127.0.0.1") || clean.contains("0.0.0.0") { return Err("Acesso a endereços locais não é permitido pela ferramenta web".into()); }
    #[cfg(target_os = "windows")]
    { let script = format!("$r=Invoke-WebRequest -UseBasicParsing -Uri '{}' -TimeoutSec 20; $r.Content", clean.replace('\'', "''")); let output=Command::new("powershell.exe").args(["-NoProfile","-NonInteractive","-Command",&script]).output().map_err(|e| format!("Falha ao iniciar leitura web: {e}"))?; let content=String::from_utf8_lossy(&output.stdout).chars().take(200_000).collect::<String>(); if !output.status.success() { return Err(String::from_utf8_lossy(&output.stderr).trim().into()); } return Ok(WebFetchResult { url: clean, title: "Página web localmente consultada".into(), content, status: 200 }); }
    #[cfg(not(target_os = "windows"))]
    { Err("A leitura web nativa está disponível no aplicativo Windows Tauri".into()) }
}
'''
needle='#[tauri::command] fn get_bridge_status'
s=s.replace(needle,insert+'\n'+needle,1)
s=s.replace('delete_desktop_shortcut, file_operation, run_allowed_process]', 'delete_desktop_shortcut, file_operation, run_allowed_process, fetch_web_page]',1)
s=s.replace('let mut context = runtime.model.new_context', 'let mut context = runtime.model.new_context',1)
# cap prompt tokens before context construction
s=s.replace('if tokens.is_empty() { return Err("O modelo não gerou tokens para o prompt".into()); } let mut context', 'if tokens.is_empty() { return Err("O modelo não gerou tokens para o prompt".into()); } let mut tokens = tokens; if tokens.len() > 500 { tokens.truncate(500); } let mut context',1)
p.write_text(s); print('web fetch added')
