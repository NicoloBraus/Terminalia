from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx'); s=p.read_text()
old='  localStorage.setItem("terminalia-audit-log", JSON.stringify([entry, ...previous].slice(0, 100)));\n  window.dispatchEvent(new CustomEvent("terminalia-audit-update"));'
new='  localStorage.setItem("terminalia-audit-log", JSON.stringify([entry, ...previous].slice(0, 100)));\n  const metrics = JSON.parse(localStorage.getItem("terminalia-local-metrics") ?? "{}") as { total?: number; executed?: number; authorized?: number; failed?: number; shells?: Record<string, number> }; metrics.total = (metrics.total ?? 0) + 1; if (status === "executed") metrics.executed = (metrics.executed ?? 0) + 1; if (status === "authorized") metrics.authorized = (metrics.authorized ?? 0) + 1; if (status === "cancelled" || status === "blocked") metrics.failed = (metrics.failed ?? 0) + 1; metrics.shells = metrics.shells ?? {}; metrics.shells[shell] = (metrics.shells[shell] ?? 0) + 1; localStorage.setItem("terminalia-local-metrics", JSON.stringify(metrics));\n  window.dispatchEvent(new CustomEvent("terminalia-audit-update"));'
if old not in s: raise SystemExit('audit body not found')
s=s.replace(old,new,1)
# add helper before detectShell
marker='function detectShell(command: string)'
helper='function learningSuggestion(command: string): string { return `Aprendizado potencial detectado: ${command}. Se este procedimento for útil, peça ao Terminalia: "salve este procedimento no meu Vault". O arquivo Markdown só será criado após essa solicitação.`; }\n'
s=s.replace(marker,helper+marker,1)
# append suggestion to successful general action response
s=s.replace('setResponse(result.stdout || result.stderr || `Comando concluído com código ${result.exit_code}`); recordAudit(actionTarget', 'setResponse(`${result.stdout || result.stderr || `Comando concluído com código ${result.exit_code}`}\\n\\n${result.exit_code === 0 ? learningSuggestion(actionTarget) : ""}`); recordAudit(actionTarget',1)
p.write_text(s); print('local metrics and learning suggestion added')
