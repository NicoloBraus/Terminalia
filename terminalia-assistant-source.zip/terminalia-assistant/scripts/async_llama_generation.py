from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/src-tauri/src/main.rs'); s=p.read_text()
old_start=s.index('#[tauri::command]\nfn generate_local_text')
old_end=s.index('\n#[tauri::command] fn get_bridge_status', old_start)
old=s[old_start:old_end]
body=old.replace('#[tauri::command]\nfn generate_local_text(prompt: String, max_tokens: u32, state: State<\'_, AppState>) -> Result<GenerateResult, String> {', 'fn generate_local_text_inner(prompt: String, max_tokens: u32, state: &AppState) -> Result<GenerateResult, String> {', 1)
new=body+'\n#[tauri::command]\nasync fn generate_local_text(prompt: String, max_tokens: u32, app: tauri::AppHandle) -> Result<GenerateResult, String> {\n    tauri::async_runtime::spawn_blocking(move || {\n        let state = app.state::<AppState>();\n        generate_local_text_inner(prompt, max_tokens, &state)\n    }).await.map_err(|error| format!("Falha na thread de geração local: {error}"))?\n}\n'
s=s[:old_start]+new+s[old_end:]
# Replace desktop command dirs usage with environment-based path.
s=s.replace('let desktop = dirs::desktop_dir().ok_or_else(|| "Não foi possível localizar a Área de Trabalho".to_string())?;', 'let profile = std::env::var("USERPROFILE").map_err(|_| "Não foi possível localizar o perfil do usuário".to_string())?;\n        let desktop = PathBuf::from(profile).join("Desktop");')
p.write_text(s); print('async generation enabled')
