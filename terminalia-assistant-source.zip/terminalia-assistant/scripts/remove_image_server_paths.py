from pathlib import Path
import re
# Frontend
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx'); s=p.read_text()
s=s.replace(', chooseImageFile, getLlamaServerStatus, startLlamaServer, generateWithLlamaServer', '',1)
s=re.sub(r' const \[attachedImage, setAttachedImage\] = useState<\{ path: string; file_name: string \} \| null>\(null\);', '', s, count=1)
s=s.replace('const mmproj = localStorage.getItem("terminalia-mmproj-path") ?? ""; try { await startLlamaServer(savedModel, mmproj || undefined, device, layers); } catch { const status = await getModelStatus(); if (!status.loaded || status.model_path !== savedModel) await loadGgufModel(savedModel, device, layers); }', 'const status = await getModelStatus(); if (!status.loaded || status.model_path !== savedModel) await loadGgufModel(savedModel, device, layers);',1)
s=re.sub(r' if \(\(!prompt && !attachedImage\) \|\| actionStep > 0\) return; if \(attachedImage\) \{.*?return; \} setMessage\(""\);', ' if (!prompt || actionStep > 0) return; setMessage("");', s, count=1)
s=s.replace('let result; try { const server = await getLlamaServerStatus(); result = server.running ? await generateWithLlamaServer(agentPrompt, 384) : await generateLocalText(agentPrompt, 384); } catch { result = await generateLocalText(agentPrompt, 384); }', 'const result = await generateLocalText(agentPrompt, 384);',1)
s=re.sub(r'<div className="flex items-center justify-between"><div className="flex items-center gap-2">\{attachedImage.*?</button></div><button onClick=\{\(\) => void sendToLocalModel\(\)\} disabled=\{!message\.trim\(\) && !attachedImage\}', '<div className="flex justify-end"><button onClick={() => void sendToLocalModel()} disabled={!message.trim()}', s, count=1)
p.write_text(s)
# Bridge
p=Path('/home/ubuntu/terminalia-assistant/client/src/lib/nativeBridge.ts'); s=p.read_text()
s=re.sub(r'export type ImageSelection.*?invoke<ImageSelection \| null>\("choose_image_file"\);\n', '', s, count=1)
s=re.sub(r'export type LlamaServerStatus.*?return \{ text: content, model_path: "llama-server", tokens: 0 \}; \}\n', '', s, count=1)
p.write_text(s)
# Rust
p=Path('/home/ubuntu/terminalia-assistant/src-tauri/src/main.rs'); s=p.read_text()
s=s.replace('use std::process::{Child, Command};','use std::process::Command;',1)
s=s.replace('struct AppState { llama_server: Mutex<Option<Child>>, working_directory:', 'struct AppState { working_directory:',1)
s=s.replace('Self { llama_server: Mutex::new(None), working_directory:', 'Self { working_directory:',1)
s=re.sub(r'\n#\[derive\(Debug, Serialize\)\] struct ImageSelection.*?\n#\[tauri::command\] fn get_bridge_status', '\n#[tauri::command] fn get_bridge_status', s, count=1, flags=re.S)
s=re.sub(r'\n#\[derive\(Debug, Serialize\)\] struct LlamaServerStatus.*?\n#\[tauri::command\] fn get_bridge_status', '\n#[tauri::command] fn get_bridge_status', s, count=1, flags=re.S)
s=s.replace(', choose_image_file, get_llama_server_status, start_llama_server, stop_llama_server', '',1)
p.write_text(s)
print('image and llama-server paths removed')
