from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/src-tauri/src/main.rs'); s=p.read_text()
start=s.index('    let rendered = match runtime.model.chat_template(None).and_then')
end=s.index('    let tokens = runtime.model.str_to_token', start)
new='''    let rendered_result: Result<String, String> = match runtime.model.chat_template(None) {
        Ok(template) => runtime.model.apply_chat_template(&template, &messages, true).map_err(|error| format!("Falha ao aplicar chat template do modelo: {error}")),
        Err(error) => Err(format!("O modelo não possui chat template compatível: {error}")),
    };
    let rendered = match rendered_result {
        Ok(value) => value,
        Err(reason) => {
            let name = runtime.model.meta_val_str("general.name").unwrap_or_default().to_ascii_lowercase();
            let arch = runtime.model.meta_val_str("general.architecture").unwrap_or_default().to_ascii_lowercase();
            if name.contains("gemma") || arch.contains("gemma") {
                format!("<start_of_turn>system\\n{}<end_of_turn>\\n<start_of_turn>user\\n{}<end_of_turn>\\n<start_of_turn>model\\n", policy, prompt_for_template)
            } else { return Err(reason); }
        }
    };
'''
s=s[:start]+new+s[end:]
p.write_text(s); print('chat template Result types fixed')
