from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx')
s=p.read_text()
needle='<p className="mt-2 text-[9px] text-[#687574]">Marque manualmente após verificar cada instalação. Este preview não altera o Windows.</p></div>'
replacement='''<div className="mt-3 flex flex-wrap gap-2"><button onClick={() => navigator.clipboard?.writeText("winget install Rustlang.Rustup\\ncargo install tauri-cli\\nwinget install Microsoft.EdgeWebView2Runtime")} className="rounded-lg border border-violet-200/20 bg-violet-200/[.06] px-2.5 py-1.5 text-[10px] font-semibold text-violet-100 hover:bg-violet-200/[.1]">Copiar roteiro completo</button><button onClick={() => { const guide = "Terminalia · preparação Windows\\n\\n1. winget install Rustlang.Rustup\\n2. cargo install tauri-cli\\n3. winget install Microsoft.EdgeWebView2Runtime\\n4. Criar a ponte PowerShell no projeto nativo\\n\\nApós cada etapa, marque o item no checklist."; const blob = new Blob([guide], { type: "text/plain" }); const url = URL.createObjectURL(blob); const link = document.createElement("a"); link.href = url; link.download = "terminalia-preparacao-windows.txt"; link.click(); URL.revokeObjectURL(url); }} className="rounded-lg border border-white/10 px-2.5 py-1.5 text-[10px] font-semibold text-[#a99b91] hover:bg-white/[.05]">Baixar roteiro</button></div><p className="mt-2 text-[9px] text-[#687574]">Marque manualmente após verificar cada instalação. Este preview não altera o Windows.</p></div>'''
if needle not in s: raise SystemExit('checklist footer missing')
s=s.replace(needle,replacement,1)
p.write_text(s)
print('setup script actions added')
