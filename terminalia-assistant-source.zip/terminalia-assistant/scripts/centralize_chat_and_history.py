from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx'); s=p.read_text()
# Add session history state alongside conversation.
s=s.replace('const [conversation, setConversation] = useState<{ role: "user" | "assistant"; text: string }[]>([]);', 'const [conversation, setConversation] = useState<{ role: "user" | "assistant"; text: string }[]>([]); const [historyOpen, setHistoryOpen] = useState(false); const [chatSessions, setChatSessions] = useState<Array<{ id: string; title: string; messages: { role: "user" | "assistant"; text: string }[] }>>(() => { try { return JSON.parse(localStorage.getItem("terminalia-chat-sessions") ?? "[]"); } catch { return []; } });',1)
# Add history helpers after currentTool init/auto effects block marker.
marker='const showResponse = (text: string) => {'
helper='const saveCurrentChat = () => { if (!conversation.length) { onReset(); return; } const first = conversation.find((item) => item.role === "user")?.text ?? "Nova conversa"; const session = { id: `${Date.now()}`, title: first.slice(0, 48), messages: conversation }; const next = [session, ...chatSessions.filter((item) => item.messages.length > 0)].slice(0, 30); localStorage.setItem("terminalia-chat-sessions", JSON.stringify(next)); setChatSessions(next); onReset(); }; const openSavedChat = (session: { messages: { role: "user" | "assistant"; text: string }[] }) => { setConversation(session.messages); localStorage.setItem("terminalia-chat-history", JSON.stringify(session.messages)); setHistoryOpen(false); }; '
s=s.replace(marker,helper+marker,1)
# Persist sessions when reset is requested through the new button; title remains current task.
# Centralize the grid/main region.
s=s.replace('className="grid min-h-0 flex-1 grid-cols-1 xl:grid-cols-[minmax(0,1fr)_300px]"', 'className="grid min-h-0 flex-1 grid-cols-1"',1)
s=s.replace('<main className="flex min-h-0 flex-col">', '<main className="mx-auto flex min-h-0 w-full max-w-5xl flex-col">',1)
# Header: replace close-only button with history and new chat controls.
s=s.replace('<button className="rounded-lg p-2 text-[#766e68]"><X size={16} /></button>', '<div className="flex items-center gap-1"><button onClick={() => setHistoryOpen((value) => !value)} className="rounded-lg px-2.5 py-2 text-[10px] font-semibold text-[#9b8f86] hover:bg-white/[.05]" title="Histórico de chats">Histórico</button><button onClick={saveCurrentChat} className="rounded-lg bg-[#f28b4b]/10 px-2.5 py-2 text-[10px] font-semibold text-[#ffb681] hover:bg-[#f28b4b]/20">+ Novo chat</button></div>',1)
# Make image selection error visible and add browser fallback input.
old='try { setAttachedImage(await chooseImageFile()); } catch { setAttachedImage(null); }'
new='try { const selected = await chooseImageFile(); setAttachedImage(selected); if (!selected) setResponse("Seleção de imagem cancelada."); } catch (error) { setResponse(error instanceof Error ? error.message : "Não foi possível abrir o seletor de imagens."); }'
s=s.replace(old,new,1)
# Add history overlay before terminal optional block.
needle='{showTerminal && <TerminalPanel />}'
overlay='{historyOpen && <div className="fixed inset-0 z-40 bg-black/50" onMouseDown={(event) => { if (event.target === event.currentTarget) setHistoryOpen(false); }}><aside className="absolute right-0 top-0 flex h-full w-full max-w-sm flex-col border-l border-white/[.1] bg-[#111616] p-5 shadow-2xl"><div className="flex items-center justify-between"><h2 className="font-display text-lg font-semibold text-[#eee4dc]">Histórico de chats</h2><button onClick={() => setHistoryOpen(false)} className="rounded-lg p-2 text-[#81766e] hover:bg-white/[.05]"><X size={15} /></button></div><button onClick={saveCurrentChat} className="mt-5 rounded-xl bg-[#f28b4b] px-3 py-2.5 text-[11px] font-bold text-[#211109]">Salvar e iniciar novo chat</button><div className="mt-5 flex-1 space-y-2 overflow-y-auto">{chatSessions.length ? chatSessions.map((session) => <button key={session.id} onClick={() => openSavedChat(session)} className="w-full rounded-xl border border-white/[.08] bg-[#151b1b] p-3 text-left hover:border-[#f28b4b]/30"><p className="truncate text-[11px] font-semibold text-[#ded4cc]">{session.title}</p><p className="mt-1 text-[9px] text-[#746b64]">{session.messages.length} mensagens</p></button>) : <p className="rounded-xl border border-dashed border-white/10 p-4 text-[10px] leading-5 text-[#80756e]">Nenhuma conversa salva ainda.</p>}</div></aside></div>}{showTerminal && <TerminalPanel />}'
if needle not in s: raise SystemExit('terminal marker not found')
s=s.replace(needle,overlay,1)
p.write_text(s); print('central chat and history applied')
