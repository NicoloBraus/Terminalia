from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/src-tauri/src/main.rs'); s=p.read_text()
s=s.replace('use std::process::Command;', 'use std::process::{Child, Command};',1)
s=s.replace('struct AppState { working_directory: Mutex<Option<String>>, inference_device:', 'struct AppState { llama_server: Mutex<Option<Child>>, working_directory: Mutex<Option<String>>, inference_device:',1)
s=s.replace('Self { working_directory: Mutex::new(None), inference_device:', 'Self { llama_server: Mutex::new(None), working_directory: Mutex::new(None), inference_device:',1)
insert=r'''
#[derive(Debug, Serialize)] struct LlamaServerStatus { running: bool, url: String, model_path: Option<String>, mmproj_path: Option<String>, message: String }
#[tauri::command]
fn get_llama_server_status(state: State<'_, AppState>) -> Result<LlamaServerStatus, String> { let mut guard=state.inner().llama_server.lock().map_err(|_| "Falha ao consultar llama-server".to_string())?; let running=match guard.as_mut(){Some(child)=>child.try_wait().map_err(|e|e.to_string())?.is_none(),None=>false}; if !running{*guard=None;} Ok(LlamaServerStatus{running,url:"http://127.0.0.1:39200".into(),model_path:None,mmproj_path:None,message:if running{"llama-server local ativo".into()}else{"llama-server local parado".into()}}) }
#[tauri::command]
fn start_llama_server(model_path: String, mmproj_path: Option<String>, device: String, gpu_layers: u32, state: State<'_, AppState>) -> Result<LlamaServerStatus, String> { let model=PathBuf::from(model_path.trim()); if !model.is_file(){return Err(format!("Modelo GGUF não encontrado: {}",model.display()));} let mut guard=state.inner().llama_server.lock().map_err(|_|"Falha ao acessar llama-server".to_string())?; if let Some(child)=guard.as_mut(){if child.try_wait().map_err(|e|e.to_string())?.is_none(){return Ok(LlamaServerStatus{running:true,url:"http://127.0.0.1:39200".into(),model_path:Some(model.display().to_string()),mmproj_path,message:"llama-server já estava ativo".into()});}} let exe=if cfg!(target_os="windows"){std::env::current_exe().ok().and_then(|p|p.parent().map(|d|d.join("llama-server.exe"))).filter(|p|p.is_file()).map(|p|p.to_string_lossy().into_owned()).unwrap_or_else(||"llama-server.exe".into())}else{"llama-server".into()}; let mut cmd=Command::new(exe); cmd.args(["--model",model.to_str().unwrap_or_default(),"--host","127.0.0.1","--port","39200","--jinja","--no-webui"]); if device!="cpu"&&gpu_layers>0{cmd.args(["--n-gpu-layers",&gpu_layers.to_string()]);} if let Some(mm)=mmproj_path.as_deref(){if PathBuf::from(mm).is_file(){cmd.args(["--mmproj",mm]);}} if let Some(parent)=model.parent(){let template=parent.join("chat_template.jinja");if template.is_file(){cmd.args(["--chat-template-file",template.to_str().unwrap_or_default()]);}} let child=cmd.spawn().map_err(|e|format!("Não foi possível iniciar llama-server.exe. Instale/coloque o runtime ao lado do Terminalia: {e}"))?; *guard=Some(child); Ok(LlamaServerStatus{running:true,url:"http://127.0.0.1:39200".into(),model_path:Some(model.display().to_string()),mmproj_path,message:"llama-server iniciado em localhost".into()}) }
#[tauri::command]
fn stop_llama_server(state: State<'_, AppState>) -> Result<LlamaServerStatus, String> { let mut guard=state.inner().llama_server.lock().map_err(|_|"Falha ao acessar llama-server".to_string())?; if let Some(mut child)=guard.take(){let _=child.kill();let _=child.wait();} Ok(LlamaServerStatus{running:false,url:"http://127.0.0.1:39200".into(),model_path:None,mmproj_path:None,message:"llama-server encerrado".into()}) }
'''
needle='#[tauri::command] fn get_bridge_status'
s=s.replace(needle,insert+'\n'+needle,1)
old='restart_network_adapter]).run'
new='restart_network_adapter, choose_image_file, get_llama_server_status, start_llama_server, stop_llama_server]).run'
if old not in s: raise SystemExit('handler tail not found')
s=s.replace(old,new,1)
p.write_text(s); print('native server commands repaired')
