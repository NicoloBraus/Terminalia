from pathlib import Path
import json

root=Path('/home/ubuntu/terminalia-assistant')
p=root/'client/src/pages/Home.tsx'; s=p.read_text()
# Use the explicit Tauri drag API and keep controls outside the draggable region.
s=s.replace('function WindowChrome() { return <div className="terminalia-titlebar" data-tauri-drag-region><div className="terminalia-titlebar-brand"><span /><b>Terminalia</b></div><div className="terminalia-window-actions"><button aria-label="Minimizar" title="Minimizar" onClick={() => void minimizeTerminaliaWindow()}><Minus size={12} /></button><button aria-label="Fechar" title="Fechar" onClick={() => void closeTerminaliaWindow()}><X size={12} /></button></div></div>; }', 'function WindowChrome() { return <div className="terminalia-titlebar"><div className="terminalia-titlebar-drag" data-tauri-drag-region onMouseDown={(event) => { if (event.button === 0 && isTauriRuntime()) void getCurrentWindow().startDragging(); }}><div className="terminalia-titlebar-brand"><span /><b>Terminalia</b></div></div><div className="terminalia-window-actions"><button aria-label="Minimizar" title="Minimizar" onMouseDown={(event) => event.stopPropagation()} onClick={(event) => { event.stopPropagation(); void minimizeTerminaliaWindow(); }}><Minus size={12} /></button><button aria-label="Fechar" title="Fechar" onMouseDown={(event) => event.stopPropagation()} onClick={(event) => { event.stopPropagation(); void closeTerminaliaWindow(); }}><X size={12} /></button></div></div>; }',1)
# Make dialogs usable at 560x420 and below.
s=s.replace('fixed inset-0 z-50 flex items-center justify-center bg-black/70 px-4', 'fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/70 px-4 py-5 sm:items-center')
s=s.replace('animate-in rounded-2xl border border-white/[.12] bg-[#151918]', 'max-h-[calc(100vh-2.5rem)] overflow-y-auto animate-in rounded-2xl border border-white/[.12] bg-[#151918]')
s=s.replace('animate-in rounded-2xl border border-rose-300/25 bg-[#171817]', 'max-h-[calc(100vh-2.5rem)] overflow-y-auto animate-in rounded-2xl border border-rose-300/25 bg-[#171817]')
p.write_text(s)

css=root/'client/src/index.css'; c=css.read_text()
c=c.replace('html, body, #root { min-height: 100%; width: 100%; }', 'html, body, #root { min-height: 100%; width: 100%; }\n#root { overflow: hidden; border-radius: 22px; }')
c=c.replace('height: 100vh; box-sizing: border-box; isolation: isolate;', 'height: 100vh; box-sizing: border-box; overflow: hidden; border-radius: 22px; isolation: isolate;',1)
if '.terminalia-titlebar-drag' not in c: c=c.replace('.terminalia-titlebar-brand {', '.terminalia-titlebar-drag { flex: 1; height: 100%; display: flex; align-items: center; cursor: grab; }\n.terminalia-titlebar-drag:active { cursor: grabbing; }\n.terminalia-titlebar-brand {',1)
css.write_text(c)

cap=root/'src-tauri/capabilities/default.json'; d=json.loads(cap.read_text()); d['permissions']=['core:default','core:window:default']; cap.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
print('borderless window repair applied')
