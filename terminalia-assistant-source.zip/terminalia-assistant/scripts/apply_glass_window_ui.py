from pathlib import Path
import json

root=Path('/home/ubuntu/terminalia-assistant')
# Tauri borderless 800x600 window, still user-resizable.
conf=root/'src-tauri/tauri.conf.json'
data=json.loads(conf.read_text())
win=data['app']['windows'][0]
win.update({'width':800,'height':600,'minWidth':560,'minHeight':420,'resizable':True,'decorations':False,'transparent':True,'shadow':True})
conf.write_text(json.dumps(data, indent=2, ensure_ascii=False)+'\n')

css=root/'client/src/index.css'; s=css.read_text()
s=s.replace('html, body, #root { min-height: 100%; }\nbody { margin: 0; background: #0d1516; color: #edf5e8; font-family: \'DM Sans\', sans-serif; }', '''html, body, #root { min-height: 100%; width: 100%; }
html, body { background: transparent; }
body { margin: 0; overflow: hidden; background: transparent; color: #edf5e8; font-family: 'DM Sans', sans-serif; }

/* Terminalia glass shell: readable translucency over the dark ambient background. */
.terminalia-shell { position: relative; isolation: isolate; min-height: 100vh; background: radial-gradient(circle at 18% 0%, rgba(242,139,75,.16), transparent 34%), radial-gradient(circle at 92% 100%, rgba(84,141,120,.14), transparent 40%), rgba(9,14,15,.72); backdrop-filter: blur(28px) saturate(125%); -webkit-backdrop-filter: blur(28px) saturate(125%); }
.terminalia-shell::before { content: ""; position: absolute; inset: 0; pointer-events: none; z-index: -1; border: 1px solid rgba(255,255,255,.13); border-radius: 22px; box-shadow: inset 0 1px 0 rgba(255,255,255,.10), 0 24px 80px rgba(0,0,0,.38); }
.terminalia-titlebar { height: 34px; display: flex; align-items: center; justify-content: space-between; padding: 0 10px 0 14px; color: rgba(239,232,224,.66); user-select: none; }
.terminalia-titlebar-brand { display: inline-flex; align-items: center; gap: 8px; font-size: 10px; letter-spacing: .08em; text-transform: uppercase; }
.terminalia-titlebar-brand span { width: 7px; height: 7px; border-radius: 999px; background: #f28b4b; box-shadow: 0 0 12px rgba(242,139,75,.65); }
.terminalia-window-actions { display: flex; gap: 4px; }
.terminalia-window-actions button { width: 25px; height: 22px; display: grid; place-items: center; border: 0; border-radius: 7px; background: rgba(255,255,255,.045); color: rgba(239,232,224,.60); }
.terminalia-window-actions button:hover { background: rgba(255,255,255,.12); color: #fff; }
.terminalia-window-actions button:last-child:hover { background: rgba(218,76,76,.72); }
.terminalia-icon-only-label { position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap; }
.terminalia-glass-panel { background: rgba(18,25,25,.58) !important; backdrop-filter: blur(22px); -webkit-backdrop-filter: blur(22px); }
@media (max-width: 600px) { .terminalia-titlebar { height: 30px; } .terminalia-shell::before { border-radius: 16px; } }
''')
css.write_text(s)

p=root/'client/src/pages/Home.tsx'; s=p.read_text()
# Native window controls, guarded for web preview.
if 'getCurrentWindow' not in s:
    s=s.replace('import { ShellKind,', 'import { getCurrentWindow } from "@tauri-apps/api/window";\nimport { ShellKind,',1)
    anchor='function cx(...values: Array<string | false | null | undefined>) { return values.filter(Boolean).join(" "); }'
    funcs='''function cx(...values: Array<string | false | null | undefined>) { return values.filter(Boolean).join(" "); }
async function minimizeTerminaliaWindow() { if (isTauriRuntime()) await getCurrentWindow().minimize(); }
async function closeTerminaliaWindow() { if (isTauriRuntime()) await getCurrentWindow().close(); }
function WindowChrome() { return <div className="terminalia-titlebar" data-tauri-drag-region><div className="terminalia-titlebar-brand"><span /><b>Terminalia</b></div><div className="terminalia-window-actions"><button aria-label="Minimizar" title="Minimizar" onClick={() => void minimizeTerminaliaWindow()}><Minus size={12} /></button><button aria-label="Fechar" title="Fechar" onClick={() => void closeTerminaliaWindow()}><X size={12} /></button></div></div>; }'''
    s=s.replace(anchor,funcs,1)
# Brand becomes icon-only, preserving an accessible label.
old='function Brand() { return <div className="flex items-center gap-3"><div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#f28b4b] text-[#1a0e08] shadow-[0_0_28px_rgba(242,139,75,.28)]"><Command size={18} strokeWidth={2.7} /></div><div><p className="font-display text-[17px] font-semibold tracking-[-.05em] text-[#f5eee7]">Terminalia</p><p className="text-[9px] uppercase tracking-[.25em] text-[#877b72]">local command studio</p></div></div>; }'
new='function Brand() { return <div className="flex items-center gap-3" aria-label="Terminalia"><div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#f28b4b] text-[#1a0e08] shadow-[0_0_28px_rgba(242,139,75,.28)]"><Command size={18} strokeWidth={2.7} /></div></div>; }'
if old not in s: raise SystemExit('Brand block not found')
s=s.replace(old,new,1)
# Tool rail labels become icon-only but keep accessible title.
s=s.replace('<span className="text-[11px] font-medium">{tool.label}</span>', '<span className="terminalia-icon-only-label">{tool.label}</span>',1)
# Add chrome to both main roots.
s=s.replace('return <div className="relative min-h-screen overflow-hidden bg-[#090b0b] text-[#f5eee7]">', 'return <div className="terminalia-shell relative min-h-screen overflow-hidden text-[#f5eee7]"><WindowChrome />',1)
s=s.replace('return <div className="flex h-screen min-h-[680px] overflow-hidden bg-[#0d1111] text-[#eee8e1]">', 'return <div className="terminalia-shell flex h-screen min-h-0 overflow-hidden text-[#eee8e1]"><WindowChrome />',1)
# Glassify the key visible cards without touching conversation text.
s=s.replace('bg-[#141a1a] p-3"><textarea', 'terminalia-glass-panel p-3"><textarea',1)
s=s.replace('bg-[#151b1b] p-2 hover:border-[#f28b4b]/30', 'terminalia-glass-panel p-2 hover:border-[#f28b4b]/30',1)
p.write_text(s)
print('glass window UI applied')
