from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx')
s=p.read_text()
s=s.replace('const [layers, setLayers] = useState(64);', 'const [layers, setLayers] = useState(64);\n  const [securityMode, setSecurityMode] = useState("balanced");', 1)
needle='<div><label className="text-[11px] font-semibold text-[#d6ccc4]">Dispositivo de inferência</label>'
section='''<div className="rounded-xl border border-[#f28b4b]/15 bg-[#f28b4b]/[.04] p-3.5"><div className="flex items-center gap-2"><ShieldCheck size={14} className="text-[#f28b4b]" /><label className="text-[11px] font-semibold text-[#d6ccc4]">Modo de segurança</label></div><p className="mt-1.5 text-[10px] leading-4 text-[#827870]">Define quando o Terminalia executa, revisa ou exige confirmação reforçada.</p><div className="mt-3 grid gap-2 sm:grid-cols-3">{[["permissive", "Permissivo", "menos interrupções"], ["balanced", "Equilibrado", "recomendado"], ["strict", "Rigoroso", "máxima proteção"]].map(([id, label, detail]) => <button key={id} onClick={() => setSecurityMode(id)} className={cx("rounded-lg border px-2.5 py-2.5 text-left transition", securityMode === id ? "border-[#f28b4b]/45 bg-[#f28b4b]/10" : "border-white/[.08] bg-[#0e1313] hover:border-white/20")}><span className={cx("block text-[10px] font-semibold", securityMode === id ? "text-[#ffb681]" : "text-[#b1a59c]")}>{label}{securityMode === id && <Check size={11} className="ml-1 inline" />}</span><span className="mt-1 block text-[9px] text-[#756b64]">{detail}</span></button>)}</div></div>'''
if needle not in s: raise SystemExit('device section not found')
s=s.replace(needle, section+needle, 1)
p.write_text(s)
print('security modes inserted')
