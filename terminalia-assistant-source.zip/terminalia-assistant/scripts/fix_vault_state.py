from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx')
s=p.read_text()
block='''const [vaultPath, setVaultPath] = useState(() => localStorage.getItem("terminalia-vault-path") ?? "");
  const chooseVault = async () => { const picker = (window as Window & { showDirectoryPicker?: () => Promise<{ name: string }> }).showDirectoryPicker; if (picker) { try { const handle = await picker(); setVaultPath(handle.name); localStorage.setItem("terminalia-vault-path", handle.name); } catch {} } };
  return <div className="rounded-xl border'''
if block not in s: raise SystemExit('broken vault block missing')
s=s.replace(block, 'return <div className="rounded-xl border', 1)
needle='const checkExecutor = async () => { setCheckingExecutor(true); try { const status = await getNativeBridgeStatus(); const ready = status === "ready-readonly"; setExecutorStatus(ready ? "ready" : "not_checked"); localStorage.setItem("terminalia-executor-status", ready ? "ready" : "not_checked"); } catch { setExecutorStatus("not_checked"); } finally { setCheckingExecutor(false); } };'
insert=needle+'\n  const [vaultPath, setVaultPath] = useState(() => localStorage.getItem("terminalia-vault-path") ?? "");\n  const chooseVault = async () => { const picker = (window as Window & { showDirectoryPicker?: () => Promise<{ name: string }> }).showDirectoryPicker; if (picker) { try { const handle = await picker(); setVaultPath(handle.name); localStorage.setItem("terminalia-vault-path", handle.name); } catch {} } };'
if needle not in s: raise SystemExit('checkExecutor needle missing')
s=s.replace(needle,insert,1)
p.write_text(s)
print('vault state fixed')
