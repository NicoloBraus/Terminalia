from pathlib import Path
text = Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx').read_text()
idx = text.index('export default function Home()')
print(repr(text[idx-80:idx+35]))
