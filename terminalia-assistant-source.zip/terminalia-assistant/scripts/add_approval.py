from pathlib import Path

path = Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx')
text = path.read_text()

panel = '''function ApprovalPanel({ onApprove, onDeny }: { onApprove: () => void; onDeny: () => void }) {
  return <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 px-4 backdrop-blur-sm"><div className="w-full max-w-[560px] animate-in rounded-2xl border border-amber-300/25 bg-[#171817] p-5 shadow-[0_25px_100px_rgba(0,0,0,.65)] sm:p-6"><div className="flex items-start gap-3"><div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-300/10 text-amber-200"><ShieldCheck size={20} /></div><div><p className="text-[10px] font-bold uppercase tracking-[.22em] text-amber-200/75">Aprovação necessária</p><h2 className="mt-2 font-display text-[20px] font-semibold tracking-[-.04em] text-[#f0e9e2]">Uma etapa precisa da sua autorização</h2><p className="mt-2 text-[11px] leading-5 text-[#978b82]">Leituras e comandos de baixo risco seguem automaticamente. Esta ação altera uma configuração global e aparece agrupada uma única vez.</p></div></div><div className="mt-5 rounded-xl border border-amber-300/20 bg-amber-300/[.05] p-4"><div className="flex items-center justify-between"><span className="text-[10px] font-bold uppercase tracking-[.16em] text-amber-100/70">risco médio · configuração do usuário</span><span className="rounded-full bg-amber-300/10 px-2 py-1 text-[9px] font-semibold text-amber-200">1 comando</span></div><code className="mt-3 block rounded-lg bg-[#0d1110] p-3 font-mono text-[11px] text-[#f2b27f]">Set-ExecutionPolicy -Scope CurrentUser RemoteSigned</code><p className="mt-3 text-[10px] leading-5 text-[#aa9a8e]">Motivo: permitir a ativação de ambientes virtuais no PowerShell. Escopo limitado ao seu usuário, sem acesso de administrador.</p></div><div className="mt-5 flex items-center gap-2 text-[10px] text-[#71847a]"><Check size={13} className="text-emerald-300" /> 4 comandos seguros já foram executados automaticamente</div><div className="mt-6 flex justify-end gap-2"><button onClick={onDeny} className="rounded-lg border border-white/10 px-3 py-2 text-[11px] font-semibold text-[#9b8f87] hover:bg-white/[.05]">Pular esta etapa</button><button onClick={onApprove} className="rounded-lg bg-amber-300 px-4 py-2 text-[11px] font-bold text-[#241a0e] hover:bg-amber-200">Aprovar e continuar</button></div></div></div>;
}

'''
export_marker = 'export default function Home()'
if 'function ApprovalPanel' not in text:
    text = text.replace(export_marker, panel + export_marker, 1)
text = text.replace('const [step, setStep] = useState(2); const currentTool', 'const [step, setStep] = useState(2); const [approvalOpen, setApprovalOpen] = useState(true); const currentTool', 1)
idx = text.index(export_marker)
workspace = text[:idx]
end = workspace.rfind('</div>; }')
if end < 0:
    raise SystemExit('workspace end not found')
workspace = workspace[:end] + '</div>{approvalOpen && <ApprovalPanel onApprove={() => setApprovalOpen(false)} onDeny={() => setApprovalOpen(false)} />}</div>; }' + workspace[end+len('</div>; }'):]
text = workspace + text[idx:]
path.write_text(text)
print('approval inserted')
