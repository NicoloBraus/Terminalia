from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx'); s=p.read_text()
start=s.find('\nfunction ApprovalPanel(')
if start >= 0:
  end=s.find('\nexport default function Home()', start)
  s=s[:start]+s[end:]
s=s.replace('{approvalOpen && <ApprovalPanel onApprove={() => setApprovalOpen(false)} onDeny={() => setApprovalOpen(false)} />}', '', 1)
s=s.replace('<div className="h-full w-3/5 rounded-full bg-[#f28b4b]" />', '<div className="h-full rounded-full bg-[#f28b4b] transition-all" style={{ width: `${Math.round((step / 3) * 100)}%` }} />', 1)
s=s.replace('<button className="rounded-lg p-2 text-[#766e68]"><Settings2 size={16} /></button>', '<span className="rounded-lg p-2 text-[#766e68]" title="Configurações disponíveis no menu lateral"><Settings2 size={16} /></span>', 1)
p.write_text(s); print('dead demo removed')
