from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx')
s=p.read_text()
s=s.replace('const [device, setDevice] = useState("auto");', 'const [device, setDevice] = useState("auto");\n  const [obsidianEnabled, setObsidianEnabled] = useState(() => localStorage.getItem("terminalia-obsidian-enabled") === "true");', 1)
start=s.rfind('<div className="rounded-xl border border-white/[.08] bg-[#0e1313] p-3.5">', 0, s.find('Vault Obsidian'))
end=s.find('<div className="flex items-center justify-between rounded-xl border border-amber-300/15', start)
if start < 0 or end < 0: raise SystemExit('obsidian boundaries not found')
new='''<div className="rounded-xl border border-white/[.08] bg-[#0e1313] p-3.5"><div className="flex items-center justify-between gap-3"><div className="flex items-center gap-2 text-[11px] font-semibold text-[#d6ccc4]"><BookOpen size={14} className="text-[#f28b4b]" /> Vault Obsidian <span className="rounded-full border border-white/10 px-1.5 py-0.5 text-[8px] font-medium text-[#827970]">opcional</span></div><button onClick={() => setObsidianEnabled((current) => { const next = !current; localStorage.setItem("terminalia-obsidian-enabled", String(next)); return next; })} className={cx("relative h-5 w-9 rounded-full transition", obsidianEnabled ? "bg-[#f28b4b]" : "bg-white/15")} aria-label={obsidianEnabled ? "Desativar Obsidian" : "Ativar Obsidian"}><span className={cx("absolute top-1 h-3 w-3 rounded-full bg-white transition", obsidianEnabled ? "left-5" : "left-1")} /></button></div><p className="mt-1.5 text-[10px] leading-4 text-[#746b64]">{obsidianEnabled ? "Procedimentos locais serão usados como contexto da IA." : "O Terminalia funciona normalmente sem acessar nenhum Vault."}</p>{obsidianEnabled && <><p className="mt-2 truncate font-mono text-[10px] text-[#746b64]">C:\\Users\\você\\Obsidian\\Procedimentos</p><button className="mt-3 rounded-lg border border-white/10 px-2.5 py-1.5 text-[10px] font-semibold text-[#b1a59c] hover:bg-white/[.05]">Escolher pasta</button></>}</div>'''
s=s[:start]+new+s[end:]
p.write_text(s)
print('obsidian optional enabled')
