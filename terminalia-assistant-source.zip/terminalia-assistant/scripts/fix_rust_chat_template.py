from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/src-tauri/src/main.rs'); s=p.read_text()
s=s.replace('use llama_cpp_2::model::{AddBos, LlamaModel};', 'use llama_cpp_2::model::{AddBos, LlamaChatMessage, LlamaModel};',1)
start=s.index('fn generate_local_text_inner(')
end=s.index('\n#[tauri::command]', start)
fn=r'''fn generate_local_text_inner(prompt: String, max_tokens: u32, state: &AppState) -> Result<GenerateResult, String> {
    if prompt.trim().is_empty() { return Err("O prompt não pode estar vazio".into()); }
    let mut loaded = state.loaded_model.lock().map_err(|_| "Falha ao acessar modelo".to_string())?;
    let runtime = loaded.as_mut().ok_or_else(|| "Nenhum modelo GGUF carregado".to_string())?;
    let policy = "Responda sempre em português do Brasil. Nunca invente informações sobre o computador. Para IPs, portas, processos, arquivos, logs, horários e resultados, use somente dados de ferramentas executadas. Se não houver verificação, diga que não foi possível verificar.";
    let messages = vec![
        LlamaChatMessage::new("system".into(), policy.into()).map_err(|e| format!("Falha ao criar mensagem de sistema: {e}"))?,
        LlamaChatMessage::new("user".into(), prompt).map_err(|e| format!("Falha ao criar mensagem do usuário: {e}"))?,
    ];
    let template = runtime.model.chat_template(None).map_err(|e| format!("O modelo não possui chat template compatível: {e}"))?;
    let rendered = runtime.model.apply_chat_template(&template, &messages, true).map_err(|e| format!("Falha ao aplicar chat template do modelo: {e}"))?;
    let tokens = runtime.model.str_to_token(&rendered, AddBos::Never).map_err(|e| format!("Falha ao tokenizar conversa formatada: {e}"))?;
    if tokens.is_empty() { return Err("O modelo não gerou tokens para a conversa".into()); }
    let mut context = runtime.model.new_context(&runtime.backend, LlamaContextParams::default().with_n_ctx(NonZeroU32::new(4096))).map_err(|e| format!("Falha ao criar contexto llama.cpp: {e}"))?;
    let mut sampler = LlamaSampler::chain_simple([
        LlamaSampler::penalties(runtime.model.n_vocab() as i32, 128, 1.1, 0.0, 0.0),
        LlamaSampler::top_k(40),
        LlamaSampler::top_p(0.90, 1),
        LlamaSampler::min_p(0.05, 1),
        LlamaSampler::temp(0.20),
        LlamaSampler::dist(1234),
    ]);
    let mut batch = LlamaBatch::new(512, 1);
    let last = (tokens.len() - 1) as i32;
    for (i, token) in tokens.into_iter().enumerate() { batch.add(token, i as i32, &[0], i as i32 == last).map_err(|e| format!("Falha ao preparar conversa: {e}"))?; }
    context.decode(&mut batch).map_err(|e| format!("Falha ao processar conversa: {e}"))?;
    let mut cursor = batch.n_tokens(); let mut output = String::new(); let mut decoder = UTF_8.new_decoder(); let mut generated = 0usize;
    while generated < max_tokens.clamp(1, 1024) as usize {
        let token = sampler.sample(&context, batch.n_tokens() - 1); sampler.accept(token);
        if runtime.model.is_eog_token(token) { break; }
        output.push_str(&runtime.model.token_to_piece(token, &mut decoder, true, None).map_err(|e| format!("Falha ao decodificar saída: {e}"))?);
        batch.clear(); batch.add(token, cursor, &[0], true).map_err(|e| format!("Falha ao preparar geração: {e}"))?;
        context.decode(&mut batch).map_err(|e| format!("Falha durante geração: {e}"))?; cursor += 1; generated += 1;
    }
    Ok(GenerateResult { text: output.trim().to_string(), model_path: runtime.model_path.clone(), tokens: generated })
}
'''
s=s[:start]+fn+s[end:]
p.write_text(s); print('rust chat template and sampler fixed')
