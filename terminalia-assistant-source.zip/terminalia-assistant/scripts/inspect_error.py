from pathlib import Path
line = Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx').read_text().splitlines()[86]
print(line[7850:8250])
