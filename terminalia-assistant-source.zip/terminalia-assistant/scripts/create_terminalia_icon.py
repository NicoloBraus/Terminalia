from pathlib import Path
from PIL import Image, ImageDraw

out = Path('/home/ubuntu/terminalia-assistant/src-tauri/icons')
out.mkdir(parents=True, exist_ok=True)
base = Image.new('RGBA', (256, 256), (18, 24, 23, 255))
draw = ImageDraw.Draw(base)
draw.rounded_rectangle((18, 18, 238, 238), radius=54, fill=(242, 139, 75, 255))
draw.ellipse((72, 72, 184, 184), fill=(36, 25, 17, 255))
draw.line((128, 88, 128, 168), fill=(255, 213, 170, 255), width=14)
draw.line((88, 128, 168, 128), fill=(255, 213, 170, 255), width=14)
base.save(out / 'icon.ico', sizes=[(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
print(out / 'icon.ico')
