from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx'); s=p.read_text()
s=s.replace('runAllowedProcess, fetchWebPage }', 'runAllowedProcess, fetchWebPage, restartNetworkAdapter }',1)
needle='const url = prompt.match(/https?:\\/\\/[^\\s)]+/i)?.[0]?.replace(/[.,;]+$/, "");'
insert='const normalizedPrompt = prompt.normalize("NFD").replace(/[\\u0300-\\u036f]/g, "").toLowerCase(); if (/(reinici|reset|desligue e ligue)/.test(normalizedPrompt) && /(wifi|wi-fi|adaptador|rede)/.test(normalizedPrompt)) { setGenerating(true); try { const result = await restartNetworkAdapter(); setResponse(result.output || "Adaptador de rede reiniciado."); } catch (error) { setResponse(error instanceof Error ? error.message : "Falha ao reiniciar o adaptador de rede."); } finally { setGenerating(false); } return; } '+needle
if needle not in s: raise SystemExit('url marker not found')
s=s.replace(needle,insert,1)
p.write_text(s); print('wifi intent wired')
