from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx'); s=p.read_text()
s=s.replace('function recordAudit(command: string, status: AuditStatus, mode = "balanced") {', 'function recordAudit(command: string, status: AuditStatus, mode = "balanced", shell = "powershell") {', 1)
s=s.replace('const entry = { id: `${Date.now()}-${Math.random()}`, command, status, mode,', 'const entry = { id: `${Date.now()}-${Math.random()}`, command, shell, status, mode,', 1)
# Only the TerminalPanel calls, in its single-line run implementation.
s=s.replace('recordAudit(current, "blocked", securityMode)', 'recordAudit(current, "blocked", securityMode, shell)', 1)
s=s.replace('recordAudit(current, "review", securityMode)', 'recordAudit(current, "review", securityMode, shell)', 1)
s=s.replace('recordAudit(current, "executed", securityMode)', 'recordAudit(current, "executed", securityMode, shell)', 1)
s=s.replace('recordAudit(current, "cancelled", securityMode)', 'recordAudit(current, "cancelled", securityMode, shell)', 1)
s=s.replace('detail: `${item.detail} · modo ${item.mode}`', 'detail: `${item.detail} · shell ${item.shell ?? "powershell"} · modo ${item.mode}`', 1)
p.write_text(s); print('audit shell added')
