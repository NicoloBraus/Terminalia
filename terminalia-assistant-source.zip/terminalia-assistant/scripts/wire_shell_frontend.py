from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx'); s=p.read_text()
s=s.replace('runNativeSafeCommand, setNativeInferencePreferences', 'runNativeSafeCommand, runStructuredCommand, setNativeInferencePreferences', 1)
needle='function TerminalPanel() {'
helper='function detectShell(command: string): "powershell" | "cmd" | "direct" { const value = command.trim().toLowerCase(); if (value.startsWith("get-") || value.startswith?.("$env:") || value === "git status") return "powershell"; if (["ipconfig /all", "ipconfig", "tasklist", "where", "whoami"].includes(value)) return "cmd"; if (["git --version", "python --version", "node --version", "pnpm --version", "cargo --version"].includes(value)) return "direct"; return "powershell"; }\n\n'
# fix accidental JS-like startsWith optional expression into valid JS
helper=helper.replace('value.startswith?.("$env:")', 'value.startsWith("$env:")')
s=s.replace(needle,helper+needle,1)
s=s.replace('const current = command.trim(); const risk = classifyCommand(current, securityMode);', 'const current = command.trim(); const shell = detectShell(current); const risk = classifyCommand(current, securityMode);', 1)
s=s.replace('setLines((prev) => [...prev, `PS> ${current}`]);', 'setLines((prev) => [...prev, `${shell}> ${current}`]);', 1)
s=s.replace('const result = await runNativeSafeCommand(current);', 'const result = await runStructuredCommand(shell, current);', 1)
s=s.replace('ponte local</span>', 'PowerShell · CMD · Direct</span>', 1)
p.write_text(s); print('frontend shell routing wired')
