from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/src-tauri/src/main.rs'); s=p.read_text()
old='let messages = vec![\n        LlamaChatMessage::new("system".into(), policy.into()).map_err(|e| format!("Falha ao criar mensagem de sistema: {e}"))?,\n        LlamaChatMessage::new("user".into(), prompt).map_err(|e| format!("Falha ao criar mensagem do usuário: {e}"))?,\n    ];\n    let prompt_for_template = messages.get(1).map(|_| prompt.clone()).unwrap_or_default();'
new='let prompt_for_template = prompt.clone();\n    let messages = vec![\n        LlamaChatMessage::new("system".into(), policy.into()).map_err(|e| format!("Falha ao criar mensagem de sistema: {e}"))?,\n        LlamaChatMessage::new("user".into(), prompt).map_err(|e| format!("Falha ao criar mensagem do usuário: {e}"))?,\n    ];'
if old not in s: raise SystemExit('message block not found')
s=s.replace(old,new,1)
s=s.replace('format!("<start_of_turn>system\\n{}<end_of_turn>\\n<start_of_turn>user\\n{}<end_of_turn>\\n<start_of_turn>model\\n", policy, prompt_for_template) .replace("<start_of_turn>user\\n<end_of_turn>", "<start_of_turn>user\\n")', 'format!("<start_of_turn>system\\n{}<end_of_turn>\\n<start_of_turn>user\\n{}<end_of_turn>\\n<start_of_turn>model\\n", policy, prompt_for_template)')
p.write_text(s); print('gemma fallback ownership fixed')
