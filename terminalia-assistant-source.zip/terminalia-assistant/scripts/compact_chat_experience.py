from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx'); s=p.read_text()
# Hide lateral tools and execution panel while retaining code for optional future access.
s=s.replace('className="hidden w-[220px] shrink-0 flex-col border-r border-white/[.07] bg-[#101414] px-4 py-5 md:flex"', 'className="hidden"', 1)
s=s.replace('className="hidden border-l border-white/[.07] bg-[#111616] xl:flex xl:flex-col"', 'className="hidden"', 1)
# Make terminal an explicit optional panel.
s=s.replace('const [conversation, setConversation]', 'const [showTerminal, setShowTerminal] = useState(false); const [responseTimeMs, setResponseTimeMs] = useState<number | null>(null); const [conversation, setConversation]', 1)
s=s.replace('<TerminalPanel />', '{showTerminal && <TerminalPanel />}', 1)
# Add auto-init after currentTool declaration.
marker='const currentTool = tools.find((tool) => tool.id === active)!; '
init='useEffect(() => { const saved = localStorage.getItem("terminalia-chat-history"); if (saved) { try { setConversation(JSON.parse(saved)); } catch { localStorage.removeItem("terminalia-chat-history"); } } }, []); useEffect(() => { localStorage.setItem("terminalia-chat-history", JSON.stringify(conversation.slice(-100))); }, [conversation]); useEffect(() => { if (!isTauriRuntime()) return; void (async () => { try { const hardware = await getNativeHardwareInfo(); const memory = hardware.memory_gb ?? 16; const layers = Number(localStorage.getItem("terminalia-gpu-layers") ?? (memory >= 32 ? "64" : memory >= 16 ? "32" : "0")); localStorage.setItem("terminalia-gpu-layers", String(layers)); await setNativeInferencePreferences(localStorage.getItem("terminalia-device") ?? "auto", layers); const savedModel = localStorage.getItem("terminalia-model-path") ?? ""; if (savedModel && !/mmproj/i.test(savedModel)) { const status = await getModelStatus(); if (!status.loaded || status.model_path !== savedModel) await loadGgufModel(savedModel, localStorage.getItem("terminalia-device") ?? "auto", layers); } } catch { /* diagnóstico e carregamento serão reavaliados ao enviar */ } })(); }, []); '
s=s.replace(marker, marker+init, 1)
# Persist response latency whenever an assistant message is shown.
s=s.replace('const showResponse = (text: string) => { setResponse(text);', 'const showResponse = (text: string) => { setResponseTimeMs(Math.round(performance.now() - responseStartedAt)); setResponse(text);', 1)
s=s.replace('const prompt = text.trim();', 'const responseStartedAt = performance.now(); const prompt = text.trim();', 1)
# Add optional terminal trigger to header settings area.
s=s.replace('<span className="rounded-lg p-2 text-[#766e68]" title="Configurações disponíveis no menu lateral"><Settings2 size={16} /></span>', '<div className="flex items-center gap-1"><button onClick={() => setShowTerminal((value) => !value)} className={cx("rounded-lg p-2", showTerminal ? "bg-[#f28b4b]/10 text-[#f28b4b]" : "text-[#766e68] hover:bg-white/[.05]")} title="Mostrar terminal opcional"><TerminalSquare size={15} /></button><span className="rounded-lg p-2 text-[#766e68]" title="Configurações disponíveis no menu lateral"><Settings2 size={16} /></span></div>', 1)
# Show response duration under the assistant transcript.
s=s.replace('{generating && <p className="ml-11 animate-pulse', '{responseTimeMs !== null && !generating && <p className="ml-11 text-[9px] text-[#687970]">Resposta em {(responseTimeMs / 1000).toFixed(2)} s</p>}{generating && <p className="ml-11 animate-pulse', 1)
# Filter mmproj from model selectors, but keep it discoverable for future visual support.
s=s.replace('availableModels.map((model) => <option', 'availableModels.filter((model) => !/mmproj/i.test(model.file_name)).map((model) => <option', 1)
s=s.replace('models.length ? models.map((model) => <button', 'models.filter((model) => !/mmproj/i.test(model.file_name)).length ? models.filter((model) => !/mmproj/i.test(model.file_name)).map((model) => <button', 1)
p.write_text(s); print('compact chat experience applied')
