from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx'); s=p.read_text()
s=s.replace('fileOperation, runAllowedProcess }', 'fileOperation, runAllowedProcess, fetchWebPage }',1)
s=s.replace('kind: "delete" | "mkdir" | "github"', 'kind: "delete" | "mkdir" | "write" | "github"',1)
old='  if (/(instal|baix|clone)/.test(normalized) && /github\\.com\\//i.test(prompt))'
# insert write before github condition
addition='  if (/(cri(e|ar)|crie)/.test(normalized) && /arquivo|ficheiro/.test(normalized)) { const target = quoted || prompt.match(/(?:arquivo|ficheiro)\\s+(?:chamad[oa]\\s+|de\\s+)?([^,.!?]+?)(?:\\s+na|\\s+em|\\s*$)/i)?.[1]?.trim(); if (target) return { kind: "write", target: `home:${target}`, args: [], label: `Criar arquivo ${target}` }; }\n'
s=s.replace(old,addition+old,1)
# Add URL handling after prompt guard
needle='const shortcut = detectDesktopShortcutIntent(prompt); const intent ='
repl='const url = prompt.match(/https?:\\/\\/[^\\s)]+/i)?.[0]?.replace(/[.,;]+$/, ""); if (url && /(acesse|acessar|abra|ler|consulte|pesquise)/i.test(prompt)) { setGenerating(true); try { const page = await fetchWebPage(url); setResponse(`${page.title}\\n\\n${page.content.slice(0, 12000)}`); setMessage(""); } catch (error) { setResponse(error instanceof Error ? error.message : "Falha ao acessar a página."); } finally { setGenerating(false); } return; } const shortcut = detectDesktopShortcutIntent(prompt); const intent ='
if needle not in s: raise SystemExit('send insertion point not found')
s=s.replace(needle,repl,1)
# Extend direct intent branch for mkdir/write
old2='if (intent?.kind === "mkdir") { setGenerating(true); try { const result = await fileOperation("create_dir", intent.target); setResponse(result.output); setMessage(""); } catch (error) { setResponse(error instanceof Error ? error.message : "Falha ao criar a pasta."); } finally { setGenerating(false); } return; }'
new2='if (intent?.kind === "mkdir" || intent?.kind === "write") { setGenerating(true); try { const result = await fileOperation(intent.kind === "mkdir" ? "create_dir" : "write", intent.target, intent.kind === "write" ? "" : undefined, false); setResponse(result.output); setMessage(""); } catch (error) { setResponse(error instanceof Error ? error.message : "Falha ao executar a operação de arquivo."); } finally { setGenerating(false); } return; }'
if old2 not in s: raise SystemExit('mkdir branch not found')
s=s.replace(old2,new2,1)
p.write_text(s); print('file and web intents wired')
