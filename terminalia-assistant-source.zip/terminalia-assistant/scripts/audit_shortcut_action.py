from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx'); s=p.read_text()
s=s.replace('const cancelAction = () => { setActionStep(0); setActionTyped(""); setResponse("A exclusão do atalho foi cancelada."); };', 'const cancelAction = () => { recordAudit(`Excluir atalho "${actionName}" da Área de Trabalho`, "cancelled", localStorage.getItem("terminalia-security-mode") ?? "balanced", "direct"); setActionStep(0); setActionTyped(""); setResponse("A exclusão do atalho foi cancelada."); };',1)
s=s.replace('const result = await deleteDesktopShortcut(actionName); setResponse(result.message);', 'const result = await deleteDesktopShortcut(actionName); recordAudit(`Excluir atalho "${actionName}" da Área de Trabalho`, result.deleted_path ? "authorized" : "cancelled", localStorage.getItem("terminalia-security-mode") ?? "balanced", "direct"); setResponse(result.message);',1)
s=s.replace('>Terminal PowerShell</span>', '>Terminal Windows</span>',1)
p.write_text(s); print('shortcut audit added')
