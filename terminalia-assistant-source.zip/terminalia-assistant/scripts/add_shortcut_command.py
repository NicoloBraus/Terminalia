from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/src-tauri/src/main.rs'); s=p.read_text()
needle='#[tauri::command]\nfn choose_models_directory()'
insert=r'''#[derive(Debug, Serialize)] struct ShortcutDeleteResult { requested_name: String, deleted_path: Option<String>, message: String }
#[tauri::command]
fn delete_desktop_shortcut(name: String) -> Result<ShortcutDeleteResult, String> {
    let clean = name.trim().trim_end_matches(".lnk").trim_end_matches(".url").to_string();
    if clean.is_empty() || clean.len() > 120 || clean.contains(['\\', '/', ':', '"', '\'']) { return Err("Nome de atalho inválido".into()); }
    #[cfg(target_os = "windows")]
    {
        let desktop = dirs::desktop_dir().ok_or_else(|| "Não foi possível localizar a Área de Trabalho".to_string())?;
        let candidates = [desktop.join(format!("{clean}.lnk")), desktop.join(format!("{clean}.url"))];
        for path in candidates { if path.is_file() { std::fs::remove_file(&path).map_err(|e| format!("Falha ao excluir o atalho: {e}"))?; return Ok(ShortcutDeleteResult { requested_name: clean, deleted_path: Some(path.display().to_string()), message: "Atalho excluído da Área de Trabalho.".into() }); } }
        Ok(ShortcutDeleteResult { requested_name: clean, deleted_path: None, message: "Nenhum atalho .lnk ou .url com esse nome foi encontrado na Área de Trabalho.".into() })
    }
    #[cfg(not(target_os = "windows"))]
    { Err("A exclusão de atalhos está disponível somente no Windows nativo.".into()) }
}

'''
if needle not in s: raise SystemExit('insert point not found')
s=s.replace(needle,insert+needle,1)
s=s.replace('unload_gguf_model, generate_local_text, run_structured_command]', 'unload_gguf_model, generate_local_text, run_structured_command, delete_desktop_shortcut]',1)
p.write_text(s); print('shortcut command added')
