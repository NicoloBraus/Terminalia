from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/src-tauri/src/main.rs'); s=p.read_text()
insert=r'''
#[derive(Debug, Serialize)] struct ObsidianContext { directory: String, files: Vec<String>, content: String }
#[tauri::command]
fn read_obsidian_context(directory: String) -> Result<ObsidianContext, String> { let root=PathBuf::from(directory.trim()); if !root.is_dir() { return Err(format!("Vault não encontrado: {}", root.display())); } let mut files=Vec::new(); let mut content=String::new(); fn walk(path:&PathBuf, files:&mut Vec<String>, content:&mut String) { if files.len()>=40 || content.len()>=120_000 { return; } if let Ok(entries)=std::fs::read_dir(path) { for entry in entries.flatten() { let p=entry.path(); if p.is_dir() { if p.file_name().and_then(|v|v.to_str()) != Some(".obsidian") { walk(&p,files,content); } } else if p.extension().and_then(|v|v.to_str()).map(|v|v.eq_ignore_ascii_case("md")).unwrap_or(false) { if let Ok(text)=std::fs::read_to_string(&p) { let remaining=120_000usize.saturating_sub(content.len()); content.push_str(&format!("\n\n--- {} ---\n{}", p.display(), text.chars().take(remaining).collect::<String>())); files.push(p.display().to_string()); } } if files.len()>=40 || content.len()>=120_000 { break; } } } } walk(&root,&mut files,&mut content); Ok(ObsidianContext { directory:root.display().to_string(), files, content }) }
'''
needle='#[tauri::command] fn get_bridge_status'
s=s.replace(needle,insert+'\n'+needle,1)
s=s.replace('fetch_web_page, restart_network_adapter]', 'fetch_web_page, restart_network_adapter, read_obsidian_context]',1)
p.write_text(s); print('obsidian context added')
