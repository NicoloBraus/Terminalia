from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx'); s=p.read_text()
old='if (!isTauriRuntime()) throw new Error("Abra o aplicativo Windows Tauri para usar a IA local. O preview web não executa llama.cpp."); const result = await generateLocalText(prompt, 256);'
new='if (!isTauriRuntime()) throw new Error("Abra o aplicativo Windows Tauri para usar a IA local. O preview web não executa llama.cpp."); const selectedPath = localStorage.getItem("terminalia-model-path") ?? ""; const status = await getModelStatus(); if (!status.loaded) { if (!selectedPath) throw new Error("Nenhum modelo GGUF está selecionado. Abra Modelos GGUF, escolha um arquivo e carregue-o antes de conversar."); const device = localStorage.getItem("terminalia-device") ?? "auto"; const layers = Number(localStorage.getItem("terminalia-gpu-layers") ?? "64"); await loadGgufModel(selectedPath, device, layers); } const result = await generateLocalText(prompt, 256);'
if old not in s: raise SystemExit('generation call not found')
s=s.replace(old,new,1)
p.write_text(s); print('automatic model loading added')
