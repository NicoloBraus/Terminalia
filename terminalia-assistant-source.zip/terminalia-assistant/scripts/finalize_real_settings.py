from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx'); s=p.read_text()
s=s.replace('const [device, setDevice] = useState("auto");', 'const [device, setDevice] = useState(() => localStorage.getItem("terminalia-device") ?? "auto");', 1)
needle='const checkExecutor = async () => { setCheckingExecutor(true); try { const status = await getNativeBridgeStatus(); const ready = status === "ready-readonly"; setExecutorStatus(ready ? "ready" : "not_checked"); localStorage.setItem("terminalia-executor-status", ready ? "ready" : "not_checked"); } catch { setExecutorStatus("not_checked"); } finally { setCheckingExecutor(false); } };'
# Add automatic hardware check after runCheck by locating its closing before checkExecutor.
if 'useEffect(() => { void runCheck(); }, []);' not in s:
    s=s.replace(needle, 'useEffect(() => { void runCheck(); }, []);\n  '+needle, 1)
old='localStorage.setItem("terminalia-review-rules", JSON.stringify(reviewRules)); window.dispatchEvent'
new='localStorage.setItem("terminalia-review-rules", JSON.stringify(reviewRules)); localStorage.setItem("terminalia-device", device); if (isTauriRuntime()) await setNativeInferencePreferences(device, layers).catch(() => undefined); window.dispatchEvent'
# async handler required
s=s.replace('onClick={() => { localStorage.setItem("terminalia-security-mode"', 'onClick={async () => { localStorage.setItem("terminalia-security-mode"', 1)
s=s.replace(old,new,1)
p.write_text(s)
print('real settings finalized')
