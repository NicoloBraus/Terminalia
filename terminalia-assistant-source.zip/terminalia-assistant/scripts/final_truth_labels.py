from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx'); s=p.read_text()
s=s.replace('<Status>motor local</Status>', '<Status>IA local · modelo necessário</Status>')
s=s.replace('Ferramenta selecionada: <strong className="text-[#c8b9ae]">{tools.find((tool) => tool.id === active)?.label}</strong>. Ela só será usada após uma ação explícita.', 'Seleção de contexto: <strong className="text-[#c8b9ae]">{tools.find((tool) => tool.id === active)?.label}</strong>. Chat e Terminal estão ativos; Web e Obsidian permanecem opcionais.')
p.write_text(s); print('truthful labels updated')
