from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx')
s=p.read_text()
s=s.replace('tools: ["Terminal"], command: item.command, detail: `${item.detail} · modo ${item.mode}`', 'tools: ["Terminal"], command: item.command, detail: `${item.detail} · modo ${item.mode}`, auditStatus: item.status')
old='  const filtered = (auditHistory.length ? auditHistory : history).filter((item) => filter === "todas" || (filter === "ativas" && item.tone === "active") || (filter === "concluídas" && item.tone === "done"));\n  const current = history.find((item) => item.id === selected) ?? history[0];'
new='''  const sourceHistory = auditHistory.length ? auditHistory : history;
  const filtered = sourceHistory.filter((item) => filter === "todas" || (filter === "executados" && item.auditStatus === "executed") || (filter === "revisão" && item.auditStatus === "review") || (filter === "autorizados" && item.auditStatus === "authorized") || (filter === "cancelados" && item.auditStatus === "cancelled") || (filter === "bloqueados" && item.auditStatus === "blocked") || (filter === "concluídas" && item.tone === "done") || (filter === "ativas" && item.tone === "active"));
  const current = sourceHistory.find((item) => item.id === selected) ?? sourceHistory[0];
  const exportAudit = () => { const blob = new Blob([JSON.stringify(audit, null, 2)], { type: "application/json" }); const url = URL.createObjectURL(blob); const link = document.createElement("a"); link.href = url; link.download = `terminalia-auditoria-${new Date().toISOString().slice(0, 10)}.json`; link.click(); URL.revokeObjectURL(url); };
  const clearAudit = () => { localStorage.removeItem("terminalia-audit-log"); setAudit([]); window.dispatchEvent(new CustomEvent("terminalia-audit-update")); };'''
if old not in s: raise SystemExit('history lines missing')
s=s.replace(old,new,1)
s=s.replace('{["todas", "ativas", "concluídas"].map((item)', '{["todas", "executados", "revisão", "autorizados", "cancelados", "bloqueados"].map((item)', 1)
oldfooter='<div className="mt-5 flex items-center justify-between rounded-xl border border-white/[.08] bg-[#0e1313] p-3.5"><div className="flex items-center gap-2 text-[10px] text-[#8c8077]"><ShieldCheck size={14} className="text-emerald-300" /> O histórico fica salvo localmente no dispositivo.</div><button className="text-[10px] font-semibold text-[#9d8e84] hover:text-[#ffb681]">Limpar histórico</button></div>'
newfooter='<div className="mt-5 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-white/[.08] bg-[#0e1313] p-3.5"><div className="flex items-center gap-2 text-[10px] text-[#8c8077]"><ShieldCheck size={14} className="text-emerald-300" /> O histórico fica salvo localmente no dispositivo.</div><div className="flex gap-2"><button onClick={exportAudit} className="rounded-lg border border-white/10 px-2.5 py-1.5 text-[10px] font-semibold text-[#a99b91] hover:bg-white/[.05]">Exportar JSON</button><button onClick={clearAudit} disabled={!audit.length} className="rounded-lg border border-rose-300/15 px-2.5 py-1.5 text-[10px] font-semibold text-rose-200/80 hover:bg-rose-300/[.06] disabled:opacity-35">Limpar histórico</button></div></div>'
if oldfooter not in s: raise SystemExit('footer missing')
s=s.replace(oldfooter,newfooter,1)
p.write_text(s)
print('history enhanced')
