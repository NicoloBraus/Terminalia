from pathlib import Path
import json

root=Path('/home/ubuntu/terminalia-assistant')
css=root/'client/src/index.css'
s=css.read_text()
s=s.replace('html, body, #root { min-height: 100%; width: 100%; }', 'html, body, #root { width: 100%; height: 100%; min-height: 100%; }')
s=s.replace('html, body { background: transparent; }', 'html, body, #root { background: transparent !important; }')
s=s.replace('min-height: 100vh; background: radial-gradient', 'min-height: 100vh; clip-path: inset(0 round 22px); background: radial-gradient', 1)
css.write_text(s)

conf=root/'src-tauri/tauri.conf.json'
data=json.loads(conf.read_text())
for window in data.get('app',{}).get('windows',[]):
    window['shadow']=False
conf.write_text(json.dumps(data, indent=2, ensure_ascii=False)+'\n')
print('window shape repair applied')
