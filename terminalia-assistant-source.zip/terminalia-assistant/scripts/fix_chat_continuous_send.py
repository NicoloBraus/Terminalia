from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx'); s=p.read_text()
s=s.replace('const [message, setMessage] = useState(""); const [response, setResponse]', 'const [message, setMessage] = useState(""); const [submittedMessages, setSubmittedMessages] = useState<string[]>([]); const [response, setResponse]',1)
s=s.replace('if (!prompt || generating || actionStep > 0) return;', 'if (!prompt || actionStep > 0) return; setMessage(""); setSubmittedMessages((items) => [...items, prompt]);',1)
# Keep a single transcript of user messages, including initial prompt only once visually.
old='{initialPrompt && <div className="flex justify-end"><div className="max-w-[700px] rounded-2xl rounded-tr-md border border-[#f28b4b]/20 bg-[#f28b4b]/[.07] px-4 py-3.5 text-[12px] leading-6 text-[#e7d4c5]">{initialPrompt}</div></div>}'
new='{initialPrompt && submittedMessages.length === 0 && <div className="flex justify-end"><div className="max-w-[700px] rounded-2xl rounded-tr-md border border-[#f28b4b]/20 bg-[#f28b4b]/[.07] px-4 py-3.5 text-[12px] leading-6 text-[#e7d4c5]">{initialPrompt}</div></div>}{submittedMessages.map((item, index) => <div key={`${item}-${index}`} className="flex justify-end"><div className="max-w-[700px] rounded-2xl rounded-tr-md border border-[#f28b4b]/20 bg-[#f28b4b]/[.07] px-4 py-3.5 text-[12px] leading-6 text-[#e7d4c5]">{item}</div></div>)}'
if old not in s: raise SystemExit('initial message JSX not found')
s=s.replace(old,new,1)
s=s.replace('disabled={generating || !message.trim()}', 'disabled={!message.trim()}',1)
p.write_text(s); print('continuous chat send fixed')
