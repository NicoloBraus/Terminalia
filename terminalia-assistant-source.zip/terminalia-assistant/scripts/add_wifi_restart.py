from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/src-tauri/src/main.rs'); s=p.read_text()
insert=r'''
#[derive(Debug, Serialize)] struct NetworkRestartResult { adapter: String, output: String, exit_code: i32 }
#[tauri::command]
fn restart_network_adapter(adapter: Option<String>) -> Result<NetworkRestartResult, String> {
    #[cfg(target_os = "windows")]
    { let name = adapter.unwrap_or_default().trim().replace('"', ""); let script = if name.is_empty() { "$a=Get-NetAdapter -Physical | Where-Object {$_.Status -eq 'Up' -and $_.Name -match 'Wi-Fi|WiFi|Wireless|WLAN'} | Select-Object -First 1; if (-not $a) { $a=Get-NetAdapter -Physical | Where-Object {$_.Status -eq 'Up'} | Select-Object -First 1 }; if (-not $a) { throw 'Nenhum adaptador de rede ativo foi encontrado.' }; Restart-NetAdapter -Name $a.Name -Confirm:$false; 'Adaptador reiniciado: ' + $a.Name".to_string() } else { format!("Restart-NetAdapter -Name '{}' -Confirm:$false; 'Adaptador reiniciado: {}'", name.replace('\'', "''"), name) }; let output=Command::new("powershell.exe").args(["-NoProfile","-NonInteractive","-ExecutionPolicy","RemoteSigned","-Command",&script]).output().map_err(|e| format!("Falha ao iniciar PowerShell: {e}"))?; let stdout=String::from_utf8_lossy(&output.stdout).trim().to_string(); let stderr=String::from_utf8_lossy(&output.stderr).trim().to_string(); if !output.status.success() { return Err(if stderr.is_empty() { "Não foi possível reiniciar o adaptador. Talvez seja necessário executar como administrador.".into() } else { stderr }); } Ok(NetworkRestartResult { adapter: name, output: stdout, exit_code: output.status.code().unwrap_or(0) }) }
    #[cfg(not(target_os = "windows"))]
    { let _ = adapter; Err("O reinício do adaptador está disponível somente no Windows nativo".into()) }
}
'''
needle='#[tauri::command] fn get_bridge_status'
s=s.replace(needle,insert+'\n'+needle,1)
s=s.replace('run_allowed_process, fetch_web_page]', 'run_allowed_process, fetch_web_page, restart_network_adapter]',1)
p.write_text(s); print('wifi restart added')
