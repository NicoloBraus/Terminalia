from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx'); s=p.read_text()
old='function WindowChrome() { return <div className="terminalia-titlebar" data-tauri-drag-region><div className="terminalia-titlebar-brand"><span /><b>Terminalia</b></div><div className="terminalia-window-actions"><button aria-label="Minimizar" title="Minimizar" onClick={() => void minimizeTerminaliaWindow()}><Minus size={12} /></button><button aria-label="Fechar" title="Fechar" onClick={() => void closeTerminaliaWindow()}><X size={12} /></button></div></div>; }'
new='function WindowChrome() { return <div className="terminalia-titlebar"><div className="terminalia-titlebar-drag" data-tauri-drag-region><div className="terminalia-titlebar-brand"><span /><b>Terminalia</b></div></div><div className="terminalia-window-actions"><button aria-label="Minimizar" title="Minimizar" onMouseDown={(event) => event.stopPropagation()} onClick={(event) => { event.stopPropagation(); void minimizeTerminaliaWindow(); }}><Minus size={12} /></button><button aria-label="Fechar" title="Fechar" onMouseDown={(event) => event.stopPropagation()} onClick={(event) => { event.stopPropagation(); void closeTerminaliaWindow(); }}><X size={12} /></button></div></div>; }'
if old not in s: raise SystemExit('WindowChrome block not found')
s=s.replace(old,new,1)
# Make every full-screen dialog viewport-aware and scrollable.
s=s.replace('fixed inset-0 z-50 flex items-center justify-center bg-black/70 px-4', 'fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/70 px-4 py-5 sm:items-center', 1)
s=s.replace('fixed inset-0 z-50 flex items-center justify-center bg-black/70 px-4', 'fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/70 px-4 py-5 sm:items-center')
# Add a max height to dialog cards, preserving their internal content and scroll.
s=s.replace('animate-in rounded-2xl border border-white/[.12] bg-[#151918]', 'max-h-[calc(100vh-2.5rem)] overflow-y-auto animate-in rounded-2xl border border-white/[.12] bg-[#151918]')
s=s.replace('animate-in rounded-2xl border border-rose-300/25 bg-[#171817]', 'max-h-[calc(100vh-2.5rem)] overflow-y-auto animate-in rounded-2xl border border-rose-300/25 bg-[#171817]')
p.write_text(s); print('window controls and dialog scrolling fixed')

css=Path('/home/ubuntu/terminalia-assistant/client/src/index.css'); c=css.read_text()
c=c.replace('.terminalia-shell { position: relative; height: 100vh; box-sizing: border-box;', '.terminalia-shell { position: relative; height: 100vh; box-sizing: border-box; overflow: hidden; border-radius: 22px;')
c=c.replace('.terminalia-titlebar { position: absolute;', '.terminalia-titlebar { position: absolute;',1)
if '.terminalia-titlebar-drag' not in c:
 c=c.replace('.terminalia-titlebar-brand {', '.terminalia-titlebar-drag { flex: 1; height: 100%; display: flex; align-items: center; }\n.terminalia-titlebar-brand {',1)
css.write_text(c); print('rounded shell clipping added')
