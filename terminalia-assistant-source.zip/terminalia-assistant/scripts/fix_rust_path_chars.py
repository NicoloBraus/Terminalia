from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/src-tauri/src/main.rs'); s=p.read_text(); s=s.replace("['" + "\\" * 4 + "',", "['" + "\\" * 2 + "',"); p.write_text(s); print('rust path escape normalized')
