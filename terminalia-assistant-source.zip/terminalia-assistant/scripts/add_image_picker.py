from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/src-tauri/src/main.rs'); s=p.read_text()
insert=r'''
#[derive(Debug, Serialize)] struct ImageSelection { path: String, file_name: String }
#[tauri::command]
fn choose_image_file() -> Result<Option<ImageSelection>, String> { #[cfg(target_os = "windows")] { let script = "Add-Type -AssemblyName System.Windows.Forms; $d=New-Object System.Windows.Forms.OpenFileDialog; $d.Filter='Imagens|*.png;*.jpg;*.jpeg;*.webp;*.bmp|Todos os arquivos|*.*'; $d.Multiselect=$false; if($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK){$d.FileName}"; let output=Command::new("powershell.exe").args(["-NoProfile","-STA","-NonInteractive","-Command",script]).output().map_err(|e| e.to_string())?; let path=String::from_utf8_lossy(&output.stdout).trim().to_string(); if path.is_empty(){Ok(None)}else{let file_name=PathBuf::from(&path).file_name().and_then(|v|v.to_str()).unwrap_or("imagem").to_string(); Ok(Some(ImageSelection{path,file_name}))}} #[cfg(not(target_os = "windows"))] { Ok(None) } }
'''
needle='#[tauri::command] fn get_bridge_status'
s=s.replace(needle,insert+'\n'+needle,1)
s=s.replace('read_obsidian_context, write_obsidian_note]', 'read_obsidian_context, write_obsidian_note, choose_image_file]',1)
p.write_text(s); print('image picker added')
