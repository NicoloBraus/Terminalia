from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/src-tauri/src/main.rs'); s=p.read_text()
s=s.replace('use tauri::State;', 'use tauri::{Manager, State};', 1)
start=s.index('fn generate_local_text_inner')
end=s.index('\n#[tauri::command]', start)
block=s[start:end].replace('state.inner().loaded_model', 'state.loaded_model')
s=s[:start]+block+s[end:]
p.write_text(s); print('E0599 state access fixed')
