$ErrorActionPreference = "Stop"

Write-Host "Terminalia - diagnóstico de compilação nativa" -ForegroundColor Cyan

$llvmCandidates = @(
  $env:LIBCLANG_PATH,
  "$env:ProgramFiles\LLVM\bin",
  "${env:ProgramFiles(x86)}\LLVM\bin",
  "$env:ChocolateyInstall\bin"
) | Where-Object { $_ -and (Test-Path $_) } | Select-Object -Unique

$libclang = $null
foreach ($candidate in $llvmCandidates) {
  $dll = Join-Path $candidate "libclang.dll"
  if (Test-Path $dll) { $libclang = $dll; break }
  $dll = Join-Path $candidate "clang.dll"
  if (Test-Path $dll) { $libclang = $dll; break }
}

if (-not $libclang) {
  Write-Host "libclang não encontrado." -ForegroundColor Yellow
  Write-Host "Instale o LLVM com: winget install -e --id LLVM.LLVM"
  Write-Host "Depois abra um novo PowerShell e execute novamente este script."
  exit 1
}

$libclangDir = Split-Path $libclang -Parent
$env:LIBCLANG_PATH = $libclangDir
Write-Host "libclang encontrado em: $libclang" -ForegroundColor Green
Write-Host "LIBCLANG_PATH definido nesta sessão como: $libclangDir"

$cmake = Get-Command cmake -ErrorAction SilentlyContinue
if (-not $cmake) {
  Write-Host "CMake não encontrado no PATH." -ForegroundColor Yellow
  Write-Host "Instale com: winget install -e --id Kitware.CMake"
  Write-Host "Depois feche e abra o PowerShell novamente."
  exit 1
}
Write-Host "CMake encontrado em: $($cmake.Source)" -ForegroundColor Green
cmake --version | Select-Object -First 1

$cl = Get-Command cl -ErrorAction SilentlyContinue
if ($cl) { Write-Host "Compilador MSVC encontrado em: $($cl.Source)" -ForegroundColor Green }
else { Write-Host "Aviso: cl.exe não está neste PATH. Use o Developer PowerShell do Visual Studio ou instale Desktop development with C++." -ForegroundColor Yellow }

Write-Host "Para persistir LIBCLANG_PATH em novas sessões:"
Write-Host "[Environment]::SetEnvironmentVariable('LIBCLANG_PATH', '$libclangDir', 'User')"
Write-Host "Diagnóstico concluído. Agora execute: pnpm tauri:dev"
