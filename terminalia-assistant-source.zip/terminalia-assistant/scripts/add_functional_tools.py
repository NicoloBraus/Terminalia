from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/src-tauri/src/main.rs'); s=p.read_text()
insert=r'''
#[derive(Debug, Serialize)] struct FileOperationResult { operation: String, path: String, output: String, changed: bool }
fn user_profile_path() -> Result<PathBuf, String> { std::env::var("USERPROFILE").map(PathBuf::from).map_err(|_| "Não foi possível localizar o perfil do usuário".into()) }
fn validate_user_path(path: &PathBuf) -> Result<(), String> { let profile = user_profile_path()?; if !path.starts_with(&profile) { return Err("Por segurança, o caminho precisa estar dentro do perfil do usuário".into()); } if path.components().any(|c| c.as_os_str() == "Windows" || c.as_os_str() == "Program Files") { return Err("Caminhos do sistema não são permitidos por esta ferramenta".into()); } Ok(()) }
#[tauri::command]
fn file_operation(operation: String, path: String, content: Option<String>, confirmed: bool) -> Result<FileOperationResult, String> {
    let target = PathBuf::from(path.trim()); validate_user_path(&target)?;
    match operation.as_str() {
        "list" => { if !target.is_dir() { return Err(format!("Pasta não encontrada: {}", target.display())); } let mut names = Vec::new(); for entry in std::fs::read_dir(&target).map_err(|e| e.to_string())?.flatten() { names.push(entry.file_name().to_string_lossy().into_owned()); } names.sort(); Ok(FileOperationResult { operation, path: target.display().to_string(), output: names.join("\n"), changed: false }) }
        "create_dir" => { std::fs::create_dir_all(&target).map_err(|e| format!("Não foi possível criar a pasta: {e}"))?; Ok(FileOperationResult { operation, path: target.display().to_string(), output: "Pasta criada com sucesso.".into(), changed: true }) }
        "write" => { if target.exists() && !confirmed { return Err("O arquivo já existe; confirmação é necessária para sobrescrever".into()); } if let Some(parent) = target.parent() { std::fs::create_dir_all(parent).map_err(|e| e.to_string())?; } std::fs::write(&target, content.unwrap_or_default()).map_err(|e| format!("Não foi possível criar o arquivo: {e}"))?; Ok(FileOperationResult { operation, path: target.display().to_string(), output: "Arquivo criado/atualizado com sucesso.".into(), changed: true }) }
        "delete" => { if !confirmed { return Err("Exclusão exige confirmação reforçada".into()); } if !target.exists() { return Err(format!("Arquivo ou pasta não encontrado: {}", target.display())); } if target == user_profile_path()? { return Err("A exclusão do perfil do usuário não é permitida".into()); } if target.is_dir() { std::fs::remove_dir_all(&target) } else { std::fs::remove_file(&target) }.map_err(|e| format!("Falha ao excluir: {e}"))?; Ok(FileOperationResult { operation, path: target.display().to_string(), output: "Exclusão concluída.".into(), changed: true }) }
        _ => Err("Operação de arquivo desconhecida".into())
    }
}
#[derive(Debug, Serialize)] struct ProcessResult { program: String, output: String, error: String, exit_code: i32 }
#[tauri::command]
fn run_allowed_process(program: String, args: Vec<String>, cwd: Option<String>, confirmed: bool) -> Result<ProcessResult, String> {
    let name = PathBuf::from(&program).file_name().and_then(|v| v.to_str()).unwrap_or(&program).to_ascii_lowercase();
    let allowed = ["git", "git.exe", "python", "python.exe", "py", "py.exe", "node", "node.exe", "npm", "npm.cmd", "pnpm", "pnpm.cmd", "cargo", "cargo.exe", "winget", "winget.exe"];
    if !allowed.contains(&name.as_str()) { return Err(format!("Executável não permitido: {name}")); }
    if !confirmed { return Err("Execução de processo exige confirmação".into()); }
    if name.starts_with("git") && args.first().map(|v| v == "clone").unwrap_or(false) && !args.get(1).map(|v| v.starts_with("https://github.com/")).unwrap_or(false) { return Err("git clone só aceita URLs HTTPS do github.com".into()); }
    let mut command = Command::new(&program); command.args(&args); if let Some(dir) = cwd { let path = PathBuf::from(dir); validate_user_path(&path)?; command.current_dir(path); }
    let output = command.output().map_err(|e| format!("Não foi possível iniciar {program}: {e}"))?;
    Ok(ProcessResult { program, output: String::from_utf8_lossy(&output.stdout).trim().into(), error: String::from_utf8_lossy(&output.stderr).trim().into(), exit_code: output.status.code().unwrap_or(-1) })
}
'''
needle='#[tauri::command] fn get_bridge_status'
s=s.replace(needle,insert+'\n'+needle,1)
s=s.replace('run_structured_command, delete_desktop_shortcut]', 'run_structured_command, delete_desktop_shortcut, file_operation, run_allowed_process]',1)
# guard empty token list
s=s.replace('let mut context = runtime.model.new_context', 'if tokens.is_empty() { return Err("O modelo não gerou tokens para o prompt".into()); } let mut context = runtime.model.new_context',1)
p.write_text(s); print('functional native tools added')
