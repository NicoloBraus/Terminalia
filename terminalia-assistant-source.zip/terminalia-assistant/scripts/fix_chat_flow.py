from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx'); s=p.read_text()
s=s.replace('const [step, setStep] = useState(2); const [approvalOpen, setApprovalOpen] = useState(true);', 'const [step, setStep] = useState(1); const [approvalOpen, setApprovalOpen] = useState(false);', 1)
s=s.replace('const sendToLocalModel = async () => { const prompt = message.trim(); if (!prompt || generating) return;', 'const sendToLocalModel = async (text = message) => { const prompt = text.trim(); if (!prompt || generating) return;', 1)
needle='}; return <div className="flex h-screen'
replacement='}; useEffect(() => { if (initialPrompt.trim()) { setMessage(initialPrompt); void sendToLocalModel(initialPrompt); } }, [initialPrompt]); return <div className="flex h-screen'
if needle not in s: raise SystemExit('workspace return marker not found')
s=s.replace(needle,replacement,1)
# Replace the first static conversation block with only dynamic user/model messages.
a=s.index('<div className="mb-5 space-y-3">', s.index('function Workspace('))
b=s.index('<TerminalPanel />', a)
dynamic='<div className="mb-5 space-y-3">{initialPrompt && <div className="flex justify-end"><div className="max-w-[700px] rounded-2xl rounded-tr-md border border-[#f28b4b]/20 bg-[#f28b4b]/[.07] px-4 py-3.5 text-[12px] leading-6 text-[#e7d4c5]">{initialPrompt}</div></div>}{response && <div className="flex gap-3"><div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#f28b4b] text-[#211109]"><Bot size={16} /></div><div className="max-w-[700px] rounded-2xl rounded-tl-md border border-white/[.08] bg-[#151b1b] px-4 py-3.5 text-[12px] leading-6 text-[#b8b0a9] whitespace-pre-wrap">{response}</div></div>}{generating && <p className="ml-11 animate-pulse text-[10px] text-[#8da196]">llama.cpp gerando localmente...</p>}</div>'
s=s[:a]+dynamic+s[b:]
# Remove the old static task transcript after TerminalPanel, preserving the composer.
a=s.index('<TerminalPanel />', s.index('function Workspace('))
b=s.index('<div className="border-t border-white/[.06] px-5 py-5', a)
s=s[:a]+'<TerminalPanel />'+s[b:]
p.write_text(s); print('chat flow fixed')
