from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx')
s=p.read_text()
needle='<div className="space-y-5"><div className="flex gap-3"><div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#f28b4b] text-[#211109]"><Bot size={16} />'
replacement='<TerminalPanel /><div className="mt-5 space-y-5"><div className="flex gap-3"><div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#f28b4b] text-[#211109]"><Bot size={16} />'
if needle not in s:
    raise SystemExit('workspace message block not found')
s=s.replace(needle,replacement,1)
p.write_text(s)
print('terminal inserted')
