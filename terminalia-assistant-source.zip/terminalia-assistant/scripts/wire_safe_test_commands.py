from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx')
s=p.read_text()
s=s.replace('import { getNativeBridgeStatus, isTauriRuntime } from "@/lib/nativeBridge";', 'import { getNativeBridgeStatus, isTauriRuntime, runNativeSafeCommand } from "@/lib/nativeBridge";', 1)
s=s.replace('const [checkingExecutor, setCheckingExecutor] = useState(false);', 'const [checkingExecutor, setCheckingExecutor] = useState(false);\n  const [bridgeOutput, setBridgeOutput] = useState("");', 1)
old='''{["Get-Location", "Get-ChildItem", "whoami"].map((command) => <button key={command} onClick={() => navigator.clipboard?.writeText(command)} className="rounded-lg border border-cyan-200/15 bg-cyan-200/[.04] px-2.5 py-1.5 font-mono text-[10px] text-cyan-100/80 transition hover:border-cyan-200/35 hover:bg-cyan-200/[.08]">{command}</button>)}'''
new='''{["Get-Location", "Get-ChildItem", "whoami"].map((command) => <button key={command} onClick={async () => { if (isTauriRuntime()) { try { const result = await runNativeSafeCommand(command); setBridgeOutput(result.stdout || result.stderr || `exit ${result.exit_code}`); } catch (error) { setBridgeOutput(error instanceof Error ? error.message : "Falha na ponte nativa"); } } else { await navigator.clipboard?.writeText(command); setBridgeOutput("Copiado no preview web. Execute dentro do aplicativo Tauri para usar a ponte."); } }} className="rounded-lg border border-cyan-200/15 bg-cyan-200/[.04] px-2.5 py-1.5 font-mono text-[10px] text-cyan-100/80 transition hover:border-cyan-200/35 hover:bg-cyan-200/[.08]">{command}</button>)}'''
if old not in s: raise SystemExit('test command map missing')
s=s.replace(old,new,1)
s=s.replace('Clique em um comando para copiá-lo; a ponte real será conectada na versão nativa.', '{bridgeOutput || "No aplicativo Tauri, clique em um comando para executar a leitura segura; no preview web ele será apenas copiado."}', 1)
p.write_text(s)
print('safe test commands wired')
