from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx')
s=p.read_text()
marker='from "lucide-react";'
if 'nativeBridge' not in s:
    s=s.replace(marker, marker+'\nimport { getNativeBridgeStatus, isTauriRuntime } from "@/lib/nativeBridge";', 1)
old='const checkExecutor = () => { setCheckingExecutor(true); window.setTimeout(() => { setCheckingExecutor(false); setExecutorStatus("ready"); localStorage.setItem("terminalia-executor-status", "ready"); }, 850); };'
new='const checkExecutor = async () => { setCheckingExecutor(true); try { const status = await getNativeBridgeStatus(); const ready = status === "ready-readonly"; setExecutorStatus(ready ? "ready" : "not_checked"); localStorage.setItem("terminalia-executor-status", ready ? "ready" : "not_checked"); } catch { setExecutorStatus("not_checked"); } finally { setCheckingExecutor(false); } };'
if old not in s: raise SystemExit('checkExecutor not found')
s=s.replace(old,new,1)
s=s.replace('A ponte PowerShell/Tauri será responsável por executar comandos no Windows. Esta tela prepara a conexão; o protótipo web ainda não executa no seu computador.', 'A ponte PowerShell/Tauri executa apenas comandos de leitura na versão nativa. No preview web, ela permanece desconectada.', 1)
p.write_text(s)
print('native bridge wired', is_tauri if False else '')
