from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx')
s=p.read_text()
needle='  const [layers, setLayers] = useState(64);\n'
insert='  const [allowRules, setAllowRules] = useState<string[]>(() => JSON.parse(localStorage.getItem("terminalia-allow-rules") ?? "[\\"Get-ChildItem\\",\\"git status\\"]"));\n  const [reviewRules, setReviewRules] = useState<string[]>(() => JSON.parse(localStorage.getItem("terminalia-review-rules") ?? "[\\"pip install\\",\\"npm install\\"]"));\n'
if s.count(needle) != 1: raise SystemExit(f'needle count {s.count(needle)}')
s=s.replace(needle, needle+insert, 1)
p.write_text(s)
print('policy state declared')
