from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx'); s=p.read_text()
old='</button></div></div></main><aside className="hidden border-l'
new='</button></div></div></div></main><aside className="hidden border-l'
if old not in s: raise SystemExit('container marker not found')
p.write_text(s.replace(old,new,1)); print('scroll container closed')
