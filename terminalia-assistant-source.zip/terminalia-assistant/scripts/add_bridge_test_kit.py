from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx')
s=p.read_text()
needle='<div><div className="flex items-center justify-between"><label className="text-[11px] font-semibold text-[#d6ccc4]">Modelo local</label>'
section='''<div className="rounded-xl border border-white/[.08] bg-[#0e1313] p-3.5"><div className="flex items-center gap-2"><TerminalSquare size={14} className="text-cyan-200" /><label className="text-[11px] font-semibold text-[#d6ccc4]">Kit de teste da ponte</label></div><p className="mt-1.5 text-[10px] leading-4 text-[#827870]">Comandos somente leitura para validar a conexão quando o aplicativo Windows estiver instalado.</p><div className="mt-3 flex flex-wrap gap-2">{["Get-Location", "Get-ChildItem", "whoami"].map((command) => <button key={command} onClick={() => navigator.clipboard?.writeText(command)} className="rounded-lg border border-cyan-200/15 bg-cyan-200/[.04] px-2.5 py-1.5 font-mono text-[10px] text-cyan-100/80 transition hover:border-cyan-200/35 hover:bg-cyan-200/[.08]">{command}</button>)}</div><p className="mt-2 text-[9px] text-[#65736e]">Clique em um comando para copiá-lo; a ponte real será conectada na versão nativa.</p></div>'''
if needle not in s: raise SystemExit('model needle missing')
s=s.replace(needle, section+needle, 1)
p.write_text(s)
print('bridge test kit added')
