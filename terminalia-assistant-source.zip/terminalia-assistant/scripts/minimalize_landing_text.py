from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/client/src/pages/Home.tsx'); s=p.read_text()
s=s.replace('<div className="animate-in"><p className="mb-4 text-[10px]', '<div className="terminalia-landing-copy animate-in"><p className="mb-4 text-[10px]', 1)
s=s.replace('<div className="mt-4"><ToolRail', '<div className="mt-4 terminalia-tool-rail"><ToolRail', 1)
s=s.replace('<div className="mx-auto mt-4 flex max-w-[500px]', '<div className="terminalia-context-note mx-auto mt-4 flex max-w-[500px]', 1)
s=s.replace('<div className="mt-6 flex flex-wrap justify-center gap-x-6 gap-y-3 text-[11px]', '<div className="terminalia-landing-hints mt-6 flex flex-wrap justify-center gap-x-6 gap-y-3 text-[11px]', 1)
s=s.replace('<p className="mt-auto pt-8 text-[10px]', '<p className="terminalia-landing-footer mt-auto pt-8 text-[10px]', 1)
css=Path('/home/ubuntu/terminalia-assistant/client/src/index.css'); c=css.read_text(); c += '\n.terminalia-landing-copy, .terminalia-landing-hints, .terminalia-landing-footer, .terminalia-context-note { display: none !important; }\n'; css.write_text(c)
p.write_text(s); print('landing text minimized')
