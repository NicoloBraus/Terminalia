from pathlib import Path
import json

root=Path('/home/ubuntu/terminalia-assistant')
cap=root/'src-tauri/capabilities/default.json'
data=json.loads(cap.read_text())
data['permissions']=[
    'core:default',
    'core:window:allow-minimize',
    'core:window:allow-destroy',
    'core:window:allow-start-dragging',
]
cap.write_text(json.dumps(data, indent=2, ensure_ascii=False)+'\n')

p=root/'client/src/pages/Home.tsx'
s=p.read_text()
s=s.replace('async function minimizeTerminaliaWindow() { if (isTauriRuntime()) await getCurrentWindow().minimize(); }', 'async function minimizeTerminaliaWindow() { if (isTauriRuntime()) await getCurrentWindow().minimize(); }')
s=s.replace('async function closeTerminaliaWindow() { if (isTauriRuntime()) await getCurrentWindow().close(); }', 'async function closeTerminaliaWindow() { if (isTauriRuntime()) await getCurrentWindow().destroy(); }')
old='function WindowChrome() { return <div className="terminalia-titlebar"><div className="terminalia-titlebar-drag" data-tauri-drag-region onMouseDown={(event) => { if (event.button === 0 && isTauriRuntime()) void getCurrentWindow().startDragging(); }}><div className="terminalia-titlebar-brand"><span /><b>Terminalia</b></div></div><div className="terminalia-window-actions"><button aria-label="Minimizar" title="Minimizar" onMouseDown={(event) => event.stopPropagation()} onClick={(event) => { event.stopPropagation(); void minimizeTerminaliaWindow(); }}><Minus size={12} /></button><button aria-label="Fechar" title="Fechar" onMouseDown={(event) => event.stopPropagation()} onClick={(event) => { event.stopPropagation(); void closeTerminaliaWindow(); }}><X size={12} /></button></div></div>; }'
new='function WindowChrome() { const dragWindow = (event: React.MouseEvent<HTMLDivElement>) => { if (event.button !== 0 || !isTauriRuntime()) return; void getCurrentWindow().startDragging().catch((error) => console.error("Terminalia: falha ao arrastar a janela", error)); }; const minimize = () => { void minimizeTerminaliaWindow().catch((error) => console.error("Terminalia: falha ao minimizar a janela", error)); }; const close = () => { void closeTerminaliaWindow().catch((error) => console.error("Terminalia: falha ao fechar a janela", error)); }; return <div className="terminalia-titlebar"><div className="terminalia-titlebar-drag" data-tauri-drag-region onMouseDown={dragWindow}><div className="terminalia-titlebar-brand"><span /><b>Terminalia</b></div></div><div className="terminalia-window-actions"><button type="button" aria-label="Minimizar" title="Minimizar" onMouseDown={(event) => event.stopPropagation()} onClick={(event) => { event.stopPropagation(); minimize(); }}><Minus size={12} /></button><button type="button" aria-label="Fechar" title="Fechar" onMouseDown={(event) => event.stopPropagation()} onClick={(event) => { event.stopPropagation(); close(); }}><X size={12} /></button></div></div>; }'
if old not in s:
    raise SystemExit('WindowChrome block not found')
s=s.replace(old,new,1)
p.write_text(s)
print('explicit window permissions and handlers applied')
