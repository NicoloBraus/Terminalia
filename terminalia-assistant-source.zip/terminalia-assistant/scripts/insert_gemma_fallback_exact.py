from pathlib import Path
p=Path('/home/ubuntu/terminalia-assistant/src-tauri/src/main.rs'); s=p.read_text()
old='''    let messages = vec![
        LlamaChatMessage::new("system".into(), policy.into()).map_err(|e| format!("Falha ao criar mensagem de sistema: {e}"))?,
        LlamaChatMessage::new("user".into(), prompt).map_err(|e| format!("Falha ao criar mensagem do usuário: {e}"))?,
    ];
    let template = runtime.model.chat_template(None).map_err(|e| format!("O modelo não possui chat template compatível: {e}"))?;
    let rendered = runtime.model.apply_chat_template(&template, &messages, true).map_err(|e| format!("Falha ao aplicar chat template do modelo: {e}"))?;'''
new='''    let prompt_for_template = prompt.clone();
    let messages = vec![
        LlamaChatMessage::new("system".into(), policy.into()).map_err(|e| format!("Falha ao criar mensagem de sistema: {e}"))?,
        LlamaChatMessage::new("user".into(), prompt).map_err(|e| format!("Falha ao criar mensagem do usuário: {e}"))?,
    ];
    let rendered = match runtime.model.chat_template(None).and_then(|template| runtime.model.apply_chat_template(&template, &messages, true)) {
        Ok(value) => value,
        Err(template_error) => {
            let name = runtime.model.meta_val_str("general.name").unwrap_or_default().to_ascii_lowercase();
            let arch = runtime.model.meta_val_str("general.architecture").unwrap_or_default().to_ascii_lowercase();
            if name.contains("gemma") || arch.contains("gemma") {
                format!("<start_of_turn>system\\n{}<end_of_turn>\\n<start_of_turn>user\\n{}<end_of_turn>\\n<start_of_turn>model\\n", policy, prompt_for_template)
            } else { return Err(format!("Falha ao aplicar chat template do modelo: {template_error}")); }
        }
    };'''
if old not in s: raise SystemExit('exact template block not found')
s=s.replace(old,new,1); p.write_text(s); print('exact Gemma fallback inserted')
