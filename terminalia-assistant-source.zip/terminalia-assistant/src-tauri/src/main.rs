#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use encoding_rs::UTF_8;
use llama_cpp_2::context::params::LlamaContextParams;
use llama_cpp_2::llama_backend::LlamaBackend;
use llama_cpp_2::llama_batch::LlamaBatch;
use llama_cpp_2::model::params::LlamaModelParams;
use llama_cpp_2::model::{AddBos, LlamaChatMessage, LlamaModel};
use llama_cpp_2::sampling::LlamaSampler;
use serde::Serialize;
use std::num::NonZeroU32;
use std::path::PathBuf;
use std::process::Command;
use std::sync::Mutex;
use tauri::{Manager, State};

struct LoadedModel { backend: LlamaBackend, model: LlamaModel, model_path: String, device: String, gpu_layers: u32 }
struct AppState { working_directory: Mutex<Option<String>>, inference_device: Mutex<String>, gpu_layers: Mutex<u32>, loaded_model: Mutex<Option<LoadedModel>> }
impl Default for AppState { fn default() -> Self { Self { working_directory: Mutex::new(None), inference_device: Mutex::new("auto".into()), gpu_layers: Mutex::new(64), loaded_model: Mutex::new(None) } } }

#[derive(Debug, Serialize)] struct CommandResult { shell: String, command: String, stdout: String, stderr: String, exit_code: i32, working_directory: String }
#[derive(Debug, Serialize)] struct HardwareInfo { cpu_threads: usize, memory_gb: Option<f64>, gpu_name: String, backend: String, runtime: String }
#[derive(Debug, Serialize)] struct InferencePreferences { device: String, gpu_layers: u32, applied: bool, message: String }
#[derive(Debug, Serialize)] struct ModelStatus { loaded: bool, model_path: Option<String>, device: Option<String>, gpu_layers: Option<u32>, backend: String }
#[derive(Debug, Serialize)] struct ModelLoadResult { loaded: bool, model_path: String, device: String, gpu_layers: u32, message: String }
#[derive(Debug, Serialize)] struct GenerateResult { text: String, model_path: String, tokens: usize }
#[derive(Debug, Serialize)] struct GgufModel { path: String, file_name: String, display_name: String, size_bytes: u64, kind: String, pair_key: String }

#[derive(Debug, Clone, Copy, PartialEq, Eq)] enum ShellKind { PowerShell, Cmd, Direct }
impl ShellKind { fn as_str(self) -> &'static str { match self { Self::PowerShell => "powershell", Self::Cmd => "cmd", Self::Direct => "direct" } } }
fn parse_shell(value: &str) -> Result<ShellKind, String> { match value { "powershell" => Ok(ShellKind::PowerShell), "cmd" => Ok(ShellKind::Cmd), "direct" => Ok(ShellKind::Direct), _ => Err("Shell inválido. Use powershell, cmd ou direct.".into()) } }
fn is_allowed_command(shell: ShellKind, command: &str) -> bool { match shell { ShellKind::PowerShell => matches!(command.trim(), "Get-Location" | "Get-ChildItem" | "whoami" | "git status"), ShellKind::Cmd => matches!(command.trim(), "ipconfig /all" | "ipconfig" | "tasklist" | "where" | "whoami"), ShellKind::Direct => matches!(command.trim(), "git --version" | "python --version" | "node --version" | "pnpm --version" | "cargo --version") } }
fn execute_structured(shell: ShellKind, normalized: &str, state: &State<'_, AppState>) -> Result<CommandResult, String> {
    if !is_allowed_command(shell, normalized) { return Err(format!("Comando fora da allowlist de {}. Nenhum processo foi iniciado.", shell.as_str())); }
    let configured_dir = state.inner().working_directory.lock().map_err(|_| "Falha ao ler diretório de trabalho".to_string())?;
    let mut process = match shell { ShellKind::PowerShell => { let mut p = Command::new("powershell.exe"); p.args(["-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "RemoteSigned", "-Command", normalized]); p }, ShellKind::Cmd => { let mut p = Command::new("cmd.exe"); p.args(["/D", "/S", "/C", normalized]); p }, ShellKind::Direct => { let mut parts = normalized.split_whitespace(); let program = parts.next().ok_or_else(|| "Comando vazio".to_string())?; let mut p = Command::new(program); p.args(parts); p } };
    if let Some(directory) = configured_dir.as_deref() { process.current_dir(directory); }
    let output = process.output().map_err(|error| format!("Não foi possível iniciar {}: {error}", shell.as_str()))?;
    Ok(CommandResult { shell: shell.as_str().into(), command: normalized.into(), stdout: String::from_utf8_lossy(&output.stdout).trim().into(), stderr: String::from_utf8_lossy(&output.stderr).trim().into(), exit_code: output.status.code().unwrap_or(-1), working_directory: std::env::current_dir().map_err(|error| error.to_string())?.display().to_string() })
}
#[tauri::command]
fn run_structured_command(shell: String, command: String, state: State<'_, AppState>) -> Result<CommandResult, String> { let kind = parse_shell(&shell)?; let normalized = command.trim().to_string(); if normalized.is_empty() { return Err("Comando vazio".into()); } execute_structured(kind, &normalized, &state) }
#[tauri::command]
fn run_safe_command(command: String, state: State<'_, AppState>) -> Result<CommandResult, String> { run_structured_command("powershell".into(), command, state) }


fn command_is_restricted(command: &str) -> bool { let c=command.to_ascii_lowercase(); c.contains("remove-item") || c.contains("del ") || c.contains("format-") || c.contains("diskpart") || c.contains("reg delete") || c.contains("shutdown") || c.contains("start-process") && c.contains("runas") || c.contains("clear-disk") || c.contains("git push") }
fn execute_general(shell: ShellKind, command: &str, state: &State<'_, AppState>) -> Result<CommandResult, String> {
    let configured_dir = state.inner().working_directory.lock().map_err(|_| "Falha ao ler diretório de trabalho".to_string())?;
    let mut process = match shell { ShellKind::PowerShell => { let mut p=Command::new("powershell.exe"); p.args(["-NoLogo","-NoProfile","-NonInteractive","-ExecutionPolicy","RemoteSigned","-Command",command]); p }, ShellKind::Cmd => { let mut p=Command::new("cmd.exe"); p.args(["/D","/S","/C",command]); p }, ShellKind::Direct => { let mut parts=command.split_whitespace(); let program=parts.next().ok_or_else(|| "Comando vazio".to_string())?; let mut p=Command::new(program); p.args(parts); p } };
    if let Some(directory)=configured_dir.as_deref() { process.current_dir(directory); }
    let output=process.output().map_err(|e| format!("Não foi possível iniciar {}: {e}", shell.as_str()))?;
    Ok(CommandResult { shell:shell.as_str().into(), command:command.into(), stdout:String::from_utf8_lossy(&output.stdout).trim().into(), stderr:String::from_utf8_lossy(&output.stderr).trim().into(), exit_code:output.status.code().unwrap_or(-1), working_directory:std::env::current_dir().map_err(|e| e.to_string())?.display().to_string() })
}
#[tauri::command]
fn run_general_command(shell: String, command: String, confirmed: bool, state: State<'_, AppState>) -> Result<CommandResult, String> { let kind=parse_shell(&shell)?; let normalized=command.trim().to_string(); if normalized.is_empty() { return Err("Comando vazio".into()); } if command_is_restricted(&normalized) && !confirmed { return Err("Este comando exige confirmação reforçada antes da execução".into()); } execute_general(kind, &normalized, &state) }

#[derive(Debug, Serialize)] struct ShortcutDeleteResult { requested_name: String, deleted_path: Option<String>, message: String }
#[tauri::command]
fn delete_desktop_shortcut(name: String) -> Result<ShortcutDeleteResult, String> {
    let clean = name.trim().trim_end_matches(".lnk").trim_end_matches(".url").to_string();
    if clean.is_empty() || clean.len() > 120 || clean.contains(['\\', '/', ':', '"', '\'']) { return Err("Nome de atalho inválido".into()); }
    #[cfg(target_os = "windows")]
    {
        let profile = std::env::var("USERPROFILE").map_err(|_| "Não foi possível localizar o perfil do usuário".to_string())?;
        let desktop = PathBuf::from(profile).join("Desktop");
        let candidates = [desktop.join(format!("{clean}.lnk")), desktop.join(format!("{clean}.url"))];
        for path in candidates { if path.is_file() { std::fs::remove_file(&path).map_err(|e| format!("Falha ao excluir o atalho: {e}"))?; return Ok(ShortcutDeleteResult { requested_name: clean, deleted_path: Some(path.display().to_string()), message: "Atalho excluído da Área de Trabalho.".into() }); } }
        Ok(ShortcutDeleteResult { requested_name: clean, deleted_path: None, message: "Nenhum atalho .lnk ou .url com esse nome foi encontrado na Área de Trabalho.".into() })
    }
    #[cfg(not(target_os = "windows"))]
    { Err("A exclusão de atalhos está disponível somente no Windows nativo.".into()) }
}

#[tauri::command]
fn choose_models_directory() -> Result<String, String> {
    #[cfg(target_os = "windows")]
    { let script = "Add-Type -AssemblyName System.Windows.Forms; $dialog = New-Object System.Windows.Forms.FolderBrowserDialog; $dialog.Description = 'Escolha a pasta dos modelos GGUF'; $dialog.ShowNewFolderButton = $true; if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { $dialog.SelectedPath }"; let output = Command::new("powershell.exe").args(["-NoProfile", "-STA", "-NonInteractive", "-Command", script]).output().map_err(|error| error.to_string())?; if !output.status.success() { return Err("Não foi possível abrir o seletor de pasta".into()); } let path = String::from_utf8_lossy(&output.stdout).trim().to_string(); if path.is_empty() { Err("Seleção cancelada".into()) } else { Ok(path) } }
    #[cfg(not(target_os = "windows"))]
    { Err("O seletor nativo de pasta está disponível no Windows Tauri".into()) }
}

#[tauri::command]
fn list_gguf_models(directory: String) -> Result<Vec<GgufModel>, String> {
    let root = PathBuf::from(&directory); if !root.is_dir() { return Err(format!("A pasta não existe: {}", root.display())); }
    let mut models = Vec::new(); let entries = std::fs::read_dir(&root).map_err(|error| format!("Não foi possível ler a pasta: {error}"))?;
    for entry in entries.flatten() { let path = entry.path(); if path.is_file() && path.extension().and_then(|v| v.to_str()).map(|v| v.eq_ignore_ascii_case("gguf")).unwrap_or(false) { let file_name = path.file_name().and_then(|v| v.to_str()).unwrap_or_default().to_string(); let lower = file_name.to_ascii_lowercase(); let is_projector = lower.contains("mmproj") || lower.contains("vision-projector") || lower.contains("multimodal-projector"); let kind = if is_projector { "projector" } else { "language" }.to_string(); let pair_key = lower.replace("mmproj", "").replace("vision-projector", "").replace("multimodal-projector", "").replace("-f16", "").replace("_f16", "").replace(".gguf", ""); let display_name = file_name.strip_suffix(".gguf").unwrap_or(&file_name).replace(['_', '-'], " "); let size_bytes = entry.metadata().map(|m| m.len()).unwrap_or(0); models.push(GgufModel { path: path.to_string_lossy().into(), file_name, display_name, size_bytes, kind, pair_key }); } }
    models.sort_by(|a, b| a.file_name.to_lowercase().cmp(&b.file_name.to_lowercase())); Ok(models)
}

#[tauri::command]
fn get_hardware_info() -> HardwareInfo {
    let cpu_threads = std::thread::available_parallelism().map(|v| v.get()).unwrap_or(1);
    #[cfg(target_os = "windows")]
    let (memory_gb, gpu_name) = { let memory = Command::new("powershell.exe").args(["-NoProfile", "-NonInteractive", "-Command", "(Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory"]).output().ok().and_then(|o| String::from_utf8_lossy(&o.stdout).trim().parse::<f64>().ok()).map(|b| (b / 1024.0_f64.powi(3)).round()); let gpu = Command::new("powershell.exe").args(["-NoProfile", "-NonInteractive", "-Command", "(Get-CimInstance Win32_VideoController | Select-Object -ExpandProperty Name) -join ', '"]).output().ok().map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string()).filter(|v| !v.is_empty()); (memory, gpu.unwrap_or_else(|| "GPU não identificada".into())) };
    #[cfg(not(target_os = "windows"))] let (memory_gb, gpu_name) = (None, "Disponível no Windows nativo".into());
    HardwareInfo { cpu_threads, memory_gb, gpu_name, backend: "llama.cpp nativo".into(), runtime: "tauri".into() }
}

#[tauri::command]
fn set_inference_preferences(device: String, gpu_layers: u32, state: State<'_, AppState>) -> Result<InferencePreferences, String> { if !matches!(device.as_str(), "auto" | "cpu" | "gpu") { return Err("Dispositivo inválido".into()); } if gpu_layers > 80 { return Err("O número de camadas deve estar entre 0 e 80".into()); } *state.inner().inference_device.lock().map_err(|_| "Falha ao salvar dispositivo".to_string())? = device.clone(); *state.inner().gpu_layers.lock().map_err(|_| "Falha ao salvar camadas".to_string())? = gpu_layers; Ok(InferencePreferences { device: device.clone(), gpu_layers, applied: true, message: format!("Preferência nativa salva: {device} com {gpu_layers} camadas GPU.") }) }

#[tauri::command]
fn get_model_status(state: State<'_, AppState>) -> Result<ModelStatus, String> { let loaded = state.inner().loaded_model.lock().map_err(|_| "Falha ao consultar modelo".to_string())?; Ok(match loaded.as_ref() { Some(m) => ModelStatus { loaded: true, model_path: Some(m.model_path.clone()), device: Some(m.device.clone()), gpu_layers: Some(m.gpu_layers), backend: "llama.cpp".into() }, None => ModelStatus { loaded: false, model_path: None, device: None, gpu_layers: None, backend: "llama.cpp".into() } }) }

#[tauri::command]
fn load_gguf_model(model_path: String, device: String, gpu_layers: u32, state: State<'_, AppState>) -> Result<ModelLoadResult, String> {
    let path = PathBuf::from(&model_path); if path.extension().and_then(|v| v.to_str()).map(|v| v.eq_ignore_ascii_case("gguf")) != Some(true) { return Err("Selecione um arquivo com extensão .gguf".into()); } if !path.is_file() { return Err(format!("Arquivo GGUF não encontrado: {}", path.display())); } if !matches!(device.as_str(), "auto" | "cpu" | "gpu") { return Err("Dispositivo inválido".into()); }
    let mut params = LlamaModelParams::default(); #[cfg(any(feature = "cuda", feature = "vulkan"))] if device != "cpu" { params = params.with_n_gpu_layers(if gpu_layers == 0 { 999 } else { gpu_layers }); }
    let backend = LlamaBackend::init().map_err(|e| format!("Falha ao iniciar backend llama.cpp: {e}"))?; let model = LlamaModel::load_from_file(&backend, &path, &params).map_err(|e| format!("Falha ao carregar GGUF: {e}"))?; let result = ModelLoadResult { loaded: true, model_path: model_path.clone(), device: device.clone(), gpu_layers, message: format!("Modelo carregado localmente pelo llama.cpp: {}", path.file_name().and_then(|n| n.to_str()).unwrap_or("modelo")) }; *state.inner().loaded_model.lock().map_err(|_| "Falha ao atualizar modelo".to_string())? = Some(LoadedModel { backend, model, model_path, device, gpu_layers }); Ok(result)
}

#[tauri::command]
fn unload_gguf_model(state: State<'_, AppState>) -> Result<ModelStatus, String> { *state.inner().loaded_model.lock().map_err(|_| "Falha ao descarregar modelo".to_string())? = None; Ok(ModelStatus { loaded: false, model_path: None, device: None, gpu_layers: None, backend: "llama.cpp".into() }) }

fn generate_local_text_inner(prompt: String, max_tokens: u32, state: &AppState) -> Result<GenerateResult, String> {
    if prompt.trim().is_empty() { return Err("O prompt não pode estar vazio".into()); }
    let mut loaded = state.loaded_model.lock().map_err(|_| "Falha ao acessar modelo".to_string())?;
    let runtime = loaded.as_mut().ok_or_else(|| "Nenhum modelo GGUF carregado".to_string())?;
    let policy = "Responda sempre em português do Brasil. Nunca invente informações sobre o computador. Para IPs, portas, processos, arquivos, logs, horários e resultados, use somente dados de ferramentas executadas. Se não houver verificação, diga que não foi possível verificar.";
    let prompt_for_template = prompt.clone();
    let messages = vec![
        LlamaChatMessage::new("system".into(), policy.into()).map_err(|e| format!("Falha ao criar mensagem de sistema: {e}"))?,
        LlamaChatMessage::new("user".into(), prompt).map_err(|e| format!("Falha ao criar mensagem do usuário: {e}"))?,
    ];
    let rendered_result: Result<String, String> = match runtime.model.chat_template(None) {
        Ok(template) => runtime.model.apply_chat_template(&template, &messages, true).map_err(|error| format!("Falha ao aplicar chat template do modelo: {error}")),
        Err(error) => Err(format!("O modelo não possui chat template compatível: {error}")),
    };
    let rendered = match rendered_result {
        Ok(value) => value,
        Err(reason) => {
            let name = runtime.model.meta_val_str("general.name").unwrap_or_default().to_ascii_lowercase();
            let arch = runtime.model.meta_val_str("general.architecture").unwrap_or_default().to_ascii_lowercase();
            if name.contains("gemma") || arch.contains("gemma") {
                format!("<start_of_turn>system\n{}<end_of_turn>\n<start_of_turn>user\n{}<end_of_turn>\n<start_of_turn>model\n", policy, prompt_for_template)
            } else { return Err(reason); }
        }
    };
    let tokens = runtime.model.str_to_token(&rendered, AddBos::Never).map_err(|e| format!("Falha ao tokenizar conversa formatada: {e}"))?;
    if tokens.is_empty() { return Err("O modelo não gerou tokens para a conversa".into()); }
    let mut context = runtime.model.new_context(&runtime.backend, LlamaContextParams::default().with_n_ctx(NonZeroU32::new(4096))).map_err(|e| format!("Falha ao criar contexto llama.cpp: {e}"))?;
    let mut sampler = LlamaSampler::chain_simple([
        LlamaSampler::penalties(runtime.model.n_vocab() as i32, 128, 1.1, 0.0, 0.0),
        LlamaSampler::top_k(40),
        LlamaSampler::top_p(0.90, 1),
        LlamaSampler::min_p(0.05, 1),
        LlamaSampler::temp(0.20),
        LlamaSampler::dist(1234),
    ]);
    let mut batch = LlamaBatch::new(512, 1);
    let last = (tokens.len() - 1) as i32;
    for (i, token) in tokens.into_iter().enumerate() { batch.add(token, i as i32, &[0], i as i32 == last).map_err(|e| format!("Falha ao preparar conversa: {e}"))?; }
    context.decode(&mut batch).map_err(|e| format!("Falha ao processar conversa: {e}"))?;
    let mut cursor = batch.n_tokens(); let mut output = String::new(); let mut decoder = UTF_8.new_decoder(); let mut generated = 0usize;
    while generated < max_tokens.clamp(1, 1024) as usize {
        let token = sampler.sample(&context, batch.n_tokens() - 1); sampler.accept(token);
        if runtime.model.is_eog_token(token) { break; }
        output.push_str(&runtime.model.token_to_piece(token, &mut decoder, true, None).map_err(|e| format!("Falha ao decodificar saída: {e}"))?);
        batch.clear(); batch.add(token, cursor, &[0], true).map_err(|e| format!("Falha ao preparar geração: {e}"))?;
        context.decode(&mut batch).map_err(|e| format!("Falha durante geração: {e}"))?; cursor += 1; generated += 1;
    }
    Ok(GenerateResult { text: output.trim().to_string(), model_path: runtime.model_path.clone(), tokens: generated })
}

#[tauri::command]
async fn generate_local_text(prompt: String, max_tokens: u32, app: tauri::AppHandle) -> Result<GenerateResult, String> {
    tauri::async_runtime::spawn_blocking(move || {
        let state = app.state::<AppState>();
        generate_local_text_inner(prompt, max_tokens, &state)
    }).await.map_err(|error| format!("Falha na thread de geração local: {error}"))?
}


#[derive(Debug, Serialize)] struct FileOperationResult { operation: String, path: String, output: String, changed: bool }
fn user_profile_path() -> Result<PathBuf, String> { std::env::var("USERPROFILE").map(PathBuf::from).map_err(|_| "Não foi possível localizar o perfil do usuário".into()) }
fn validate_user_path(path: &PathBuf) -> Result<(), String> { let profile = user_profile_path()?; if !path.starts_with(&profile) { return Err("Por segurança, o caminho precisa estar dentro do perfil do usuário".into()); } if path.components().any(|c| c.as_os_str() == "Windows" || c.as_os_str() == "Program Files") { return Err("Caminhos do sistema não são permitidos por esta ferramenta".into()); } Ok(()) }
#[tauri::command]
fn file_operation(operation: String, path: String, content: Option<String>, confirmed: bool) -> Result<FileOperationResult, String> {
    let raw_path = path.trim(); let profile = user_profile_path()?; let target = if let Some(rest) = raw_path.strip_prefix("desktop:") { profile.join("Desktop").join(rest.trim_start_matches(['\\', '/'])) } else if let Some(rest) = raw_path.strip_prefix("home:") { profile.join(rest.trim_start_matches(['\\', '/'])) } else { PathBuf::from(raw_path) }; validate_user_path(&target)?;
    match operation.as_str() {
        "list" => { if !target.is_dir() { return Err(format!("Pasta não encontrada: {}", target.display())); } let mut names = Vec::new(); for entry in std::fs::read_dir(&target).map_err(|e| e.to_string())?.flatten() { names.push(entry.file_name().to_string_lossy().into_owned()); } names.sort(); Ok(FileOperationResult { operation, path: target.display().to_string(), output: names.join("\n"), changed: false }) }
        "create_dir" => { std::fs::create_dir_all(&target).map_err(|e| format!("Não foi possível criar a pasta: {e}"))?; Ok(FileOperationResult { operation, path: target.display().to_string(), output: "Pasta criada com sucesso.".into(), changed: true }) }
        "write" => { if target.exists() && !confirmed { return Err("O arquivo já existe; confirmação é necessária para sobrescrever".into()); } if let Some(parent) = target.parent() { std::fs::create_dir_all(parent).map_err(|e| e.to_string())?; } std::fs::write(&target, content.unwrap_or_default()).map_err(|e| format!("Não foi possível criar o arquivo: {e}"))?; Ok(FileOperationResult { operation, path: target.display().to_string(), output: "Arquivo criado/atualizado com sucesso.".into(), changed: true }) }
        "delete" => { if !confirmed { return Err("Exclusão exige confirmação reforçada".into()); } if !target.exists() { return Err(format!("Arquivo ou pasta não encontrado: {}", target.display())); } if target == user_profile_path()? { return Err("A exclusão do perfil do usuário não é permitida".into()); } if target.is_dir() { std::fs::remove_dir_all(&target) } else { std::fs::remove_file(&target) }.map_err(|e| format!("Falha ao excluir: {e}"))?; Ok(FileOperationResult { operation, path: target.display().to_string(), output: "Exclusão concluída.".into(), changed: true }) }
        _ => Err("Operação de arquivo desconhecida".into())
    }
}
#[derive(Debug, Serialize)] struct ProcessResult { program: String, output: String, error: String, exit_code: i32 }
#[tauri::command]
fn run_allowed_process(program: String, args: Vec<String>, cwd: Option<String>, confirmed: bool) -> Result<ProcessResult, String> {
    let name = PathBuf::from(&program).file_name().and_then(|v| v.to_str()).unwrap_or(&program).to_ascii_lowercase();
    let allowed = ["git", "git.exe", "python", "python.exe", "py", "py.exe", "node", "node.exe", "npm", "npm.cmd", "pnpm", "pnpm.cmd", "cargo", "cargo.exe", "winget", "winget.exe"];
    if !allowed.contains(&name.as_str()) { return Err(format!("Executável não permitido: {name}")); }
    if !confirmed { return Err("Execução de processo exige confirmação".into()); }
    if name.starts_with("git") && args.first().map(|v| v == "clone").unwrap_or(false) && !args.get(1).map(|v| v.starts_with("https://github.com/")).unwrap_or(false) { return Err("git clone só aceita URLs HTTPS do github.com".into()); }
    let mut command = Command::new(&program); command.args(&args); if let Some(dir) = cwd { let raw = dir.trim(); let profile = user_profile_path()?; let path = if raw == "home:" { profile } else if let Some(rest) = raw.strip_prefix("desktop:") { user_profile_path()?.join("Desktop").join(rest.trim_start_matches(['\\', '/'])) } else { PathBuf::from(raw) }; validate_user_path(&path)?; command.current_dir(path); }
    let output = command.output().map_err(|e| format!("Não foi possível iniciar {program}: {e}"))?;
    Ok(ProcessResult { program, output: String::from_utf8_lossy(&output.stdout).trim().into(), error: String::from_utf8_lossy(&output.stderr).trim().into(), exit_code: output.status.code().unwrap_or(-1) })
}


#[derive(Debug, Serialize)] struct WebFetchResult { url: String, title: String, content: String, status: i32 }
#[tauri::command]
fn fetch_web_page(url: String) -> Result<WebFetchResult, String> {
    let clean = url.trim().to_string(); if !(clean.starts_with("https://") || clean.starts_with("http://")) { return Err("A URL precisa começar com http:// ou https://".into()); } if clean.contains("localhost") || clean.contains("127.0.0.1") || clean.contains("0.0.0.0") { return Err("Acesso a endereços locais não é permitido pela ferramenta web".into()); }
    #[cfg(target_os = "windows")]
    { let script = format!("$r=Invoke-WebRequest -UseBasicParsing -Uri '{}' -TimeoutSec 20; $r.Content", clean.replace('\'', "''")); let output=Command::new("powershell.exe").args(["-NoProfile","-NonInteractive","-Command",&script]).output().map_err(|e| format!("Falha ao iniciar leitura web: {e}"))?; let content=String::from_utf8_lossy(&output.stdout).chars().take(200_000).collect::<String>(); if !output.status.success() { return Err(String::from_utf8_lossy(&output.stderr).trim().into()); } return Ok(WebFetchResult { url: clean, title: "Página web localmente consultada".into(), content, status: 200 }); }
    #[cfg(not(target_os = "windows"))]
    { Err("A leitura web nativa está disponível no aplicativo Windows Tauri".into()) }
}


#[derive(Debug, Serialize)] struct NetworkRestartResult { adapter: String, output: String, exit_code: i32 }
#[tauri::command]
fn restart_network_adapter(adapter: Option<String>) -> Result<NetworkRestartResult, String> {
    #[cfg(target_os = "windows")]
    { let name = adapter.unwrap_or_default().trim().replace('"', ""); let script = if name.is_empty() { "$a=Get-NetAdapter -Physical | Where-Object {$_.Status -eq 'Up' -and $_.Name -match 'Wi-Fi|WiFi|Wireless|WLAN'} | Select-Object -First 1; if (-not $a) { $a=Get-NetAdapter -Physical | Where-Object {$_.Status -eq 'Up'} | Select-Object -First 1 }; if (-not $a) { throw 'Nenhum adaptador de rede ativo foi encontrado.' }; Restart-NetAdapter -Name $a.Name -Confirm:$false; 'Adaptador reiniciado: ' + $a.Name".to_string() } else { format!("Restart-NetAdapter -Name '{}' -Confirm:$false; 'Adaptador reiniciado: {}'", name.replace('\'', "''"), name) }; let output=Command::new("powershell.exe").args(["-NoProfile","-NonInteractive","-ExecutionPolicy","RemoteSigned","-Command",&script]).output().map_err(|e| format!("Falha ao iniciar PowerShell: {e}"))?; let stdout=String::from_utf8_lossy(&output.stdout).trim().to_string(); let stderr=String::from_utf8_lossy(&output.stderr).trim().to_string(); if !output.status.success() { return Err(if stderr.is_empty() { "Não foi possível reiniciar o adaptador. Talvez seja necessário executar como administrador.".into() } else { stderr }); } Ok(NetworkRestartResult { adapter: name, output: stdout, exit_code: output.status.code().unwrap_or(0) }) }
    #[cfg(not(target_os = "windows"))]
    { let _ = adapter; Err("O reinício do adaptador está disponível somente no Windows nativo".into()) }
}


#[tauri::command]
fn write_obsidian_note(directory: String, title: String, content: String) -> Result<String, String> { let root=PathBuf::from(directory.trim()); if !root.is_dir() { return Err("Vault não encontrado".into()); } let clean=title.trim().chars().filter(|c| c.is_alphanumeric() || *c==' ' || *c=='-' || *c=='_').collect::<String>(); if clean.is_empty() { return Err("Título inválido".into()); } let path=root.join(format!("{clean}.md")); std::fs::write(&path, content.chars().take(40_000).collect::<String>()).map_err(|e| format!("Falha ao salvar nota: {e}"))?; Ok(path.display().to_string()) }


#[tauri::command] fn get_bridge_status() -> &'static str { "ready-readonly" }
fn main() { tauri::Builder::default().manage(AppState::default()).invoke_handler(tauri::generate_handler![run_safe_command, choose_models_directory, list_gguf_models, get_bridge_status, get_hardware_info, set_inference_preferences, get_model_status, load_gguf_model, unload_gguf_model, generate_local_text, run_structured_command, run_general_command, delete_desktop_shortcut, file_operation, run_allowed_process, fetch_web_page, restart_network_adapter]).run(tauri::generate_context!()).expect("erro ao iniciar o Terminalia"); }
