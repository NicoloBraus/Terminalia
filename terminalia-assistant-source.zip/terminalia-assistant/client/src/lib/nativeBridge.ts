import { invoke } from "@tauri-apps/api/core";
export type ShellKind = "powershell" | "cmd" | "direct";
export type NativeCommandResult = { shell: ShellKind; command: string; stdout: string; stderr: string; exit_code: number; working_directory: string };
export type NativeHardwareInfo = { cpu_threads: number; memory_gb: number | null; gpu_name: string; backend: string; runtime: string };
export type InferencePreferences = { device: string; gpu_layers: number; applied: boolean; message: string };
export type ModelStatus = { loaded: boolean; model_path: string | null; device: string | null; gpu_layers: number | null; backend: string };
export type ModelLoadResult = { loaded: boolean; model_path: string; device: string; gpu_layers: number; message: string };
export type GenerateResult = { text: string; model_path: string; tokens: number };
export const isTauriRuntime = () => Boolean((window as Window & { __TAURI_INTERNALS__?: unknown }).__TAURI_INTERNALS__);
export async function getNativeBridgeStatus(): Promise<string> { if (!isTauriRuntime()) return "web-preview"; return invoke<string>("get_bridge_status"); }
export async function getNativeHardwareInfo(): Promise<NativeHardwareInfo> { if (!isTauriRuntime()) throw new Error("O diagnóstico nativo só está disponível no aplicativo Tauri."); return invoke<NativeHardwareInfo>("get_hardware_info"); }
export async function setNativeInferencePreferences(device: string, gpuLayers: number): Promise<InferencePreferences> { if (!isTauriRuntime()) throw new Error("As preferências nativas só estão disponíveis no aplicativo Tauri."); return invoke<InferencePreferences>("set_inference_preferences", { device, gpuLayers }); }
export async function chooseModelsDirectory(): Promise<string> { if (!isTauriRuntime()) throw new Error("O seletor nativo só está disponível no aplicativo Tauri."); return invoke<string>("choose_models_directory"); }
export async function listGgufModels(directory: string): Promise<GgufModel[]> { if (!isTauriRuntime()) return []; return invoke<GgufModel[]>("list_gguf_models", { directory }); }
export async function getModelStatus(): Promise<ModelStatus> { if (!isTauriRuntime()) return { loaded: false, model_path: null, device: null, gpu_layers: null, backend: "web-preview" }; return invoke<ModelStatus>("get_model_status"); }
export async function loadGgufModel(modelPath: string, device = "auto", gpuLayers = 64): Promise<ModelLoadResult> { if (!isTauriRuntime()) throw new Error("O carregamento GGUF só está disponível no aplicativo Tauri."); return invoke<ModelLoadResult>("load_gguf_model", { modelPath, device, gpuLayers }); }
export async function unloadGgufModel(): Promise<ModelStatus> { if (!isTauriRuntime()) throw new Error("O carregamento GGUF só está disponível no aplicativo Tauri."); return invoke<ModelStatus>("unload_gguf_model"); }
export async function generateLocalText(prompt: string, maxTokens = 256): Promise<GenerateResult> { if (!isTauriRuntime()) throw new Error("A geração local só está disponível no aplicativo Tauri."); return invoke<GenerateResult>("generate_local_text", { prompt, maxTokens }); }
export async function runStructuredCommand(shell: ShellKind, command: string): Promise<NativeCommandResult> { if (!isTauriRuntime()) throw new Error("A execução estruturada só está disponível no aplicativo Windows Tauri."); return invoke<NativeCommandResult>("run_structured_command", { shell, command }); }
export async function runNativeSafeCommand(command: string): Promise<NativeCommandResult> { return runStructuredCommand("powershell", command); }

export type ShortcutDeleteResult = { requested_name: string; deleted_path: string | null; message: string };
export async function deleteDesktopShortcut(name: string): Promise<ShortcutDeleteResult> { if (!isTauriRuntime()) throw new Error("A exclusão de atalhos só está disponível no aplicativo Windows Tauri."); return invoke<ShortcutDeleteResult>("delete_desktop_shortcut", { name }); }

export type FileOperationResult = { operation: string; path: string; output: string; changed: boolean };
export type ProcessResult = { program: string; output: string; error: string; exit_code: number };
export async function fileOperation(operation: "list" | "create_dir" | "write" | "delete", path: string, content?: string, confirmed = false): Promise<FileOperationResult> { if (!isTauriRuntime()) throw new Error("Operações locais só estão disponíveis no aplicativo Windows Tauri."); return invoke<FileOperationResult>("file_operation", { operation, path, content: content ?? null, confirmed }); }
export async function runAllowedProcess(program: string, args: string[], cwd?: string, confirmed = false): Promise<ProcessResult> { if (!isTauriRuntime()) throw new Error("Processos locais só estão disponíveis no aplicativo Windows Tauri."); return invoke<ProcessResult>("run_allowed_process", { program, args, cwd: cwd ?? null, confirmed }); }

export type WebFetchResult = { url: string; title: string; content: string; status: number };
export async function fetchWebPage(url: string): Promise<WebFetchResult> { if (!isTauriRuntime()) throw new Error("A leitura web só está disponível no aplicativo Windows Tauri."); return invoke<WebFetchResult>("fetch_web_page", { url }); }

export type NetworkRestartResult = { adapter: string; output: string; exit_code: number };
export async function restartNetworkAdapter(adapter?: string): Promise<NetworkRestartResult> { if (!isTauriRuntime()) throw new Error("O reinício do adaptador só está disponível no aplicativo Windows Tauri."); return invoke<NetworkRestartResult>("restart_network_adapter", { adapter: adapter ?? null }); }

export async function runGeneralCommand(shell: ShellKind, command: string, confirmed = false): Promise<NativeCommandResult> { if (!isTauriRuntime()) throw new Error("O executor geral só está disponível no aplicativo Windows Tauri."); return invoke<NativeCommandResult>("run_general_command", { shell, command, confirmed }); }

export type ObsidianContext = { directory: string; files: string[]; content: string };
export async function readObsidianContext(directory: string): Promise<ObsidianContext> { if (!isTauriRuntime()) throw new Error("O Vault Obsidian só está disponível no aplicativo Windows Tauri."); return invoke<ObsidianContext>("read_obsidian_context", { directory }); }

export async function writeObsidianNote(directory: string, title: string, content: string): Promise<string> { if (!isTauriRuntime()) throw new Error("O Vault Obsidian só está disponível no aplicativo Windows Tauri."); return invoke<string>("write_obsidian_note", { directory, title, content }); }

export type GgufModel = { path: string; file_name: string; display_name: string; size_bytes: number; kind?: "language" | "projector"; pair_key?: string };

