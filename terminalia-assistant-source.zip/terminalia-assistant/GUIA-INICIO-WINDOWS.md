# Terminalia — Guia de início no Windows

## Situação atual do projeto

O repositório agora contém a interface React/Vite e a base nativa Tauri. A ponte Rust agora distingue três modos: PowerShell, CMD e executável direto. O shell é escolhido antes da execução, validado por uma allowlist própria e registrado no Histórico. Nenhum shell recebe uma string arbitrária sem validação.

Comandos permitidos atualmente:

```text
PowerShell: Get-Location, Get-ChildItem, whoami, git status
CMD:        ipconfig, ipconfig /all, tasklist, where, whoami
Direct:     git --version, python --version, node --version, pnpm --version, cargo --version
```

Qualquer outro comando é recusado pelo Rust antes de iniciar qualquer processo. O projeto ainda não libera escrita em arquivos, instalação de dependências, UAC ou comandos destrutivos.

## Obsidian é opcional

O Terminalia funciona normalmente sem acessar o Obsidian. O Vault fica **desativado por padrão** e só será usado se o usuário ativar a opção nas Configurações e escolher uma pasta.

Sem o Vault, continuam disponíveis o chat, o terminal, o histórico, a pesquisa web e os modelos locais. Nenhum arquivo `.md` é lido quando a opção está desativada.

## Modelos GGUF

Na tela **Modelos GGUF**, use **Escolher** para selecionar qualquer pasta em qualquer unidade, por exemplo `D:\Modelos\GGUF` ou `E:\IA`. O caminho fica salvo localmente para as próximas inicializações.

O Terminalia procura automaticamente todos os arquivos com extensão `.gguf` nessa pasta. O nome do arquivo não precisa seguir um padrão específico: modelos Qwen, Llama, Mistral, DeepSeek, Gemma, Phi ou outros modelos compatíveis com llama.cpp podem ser selecionados pelo arquivo encontrado.

O tamanho e o nome são obtidos do arquivo. O caminho completo é enviado ao backend nativo somente quando o usuário clica em **Carregar modelo**. O arquivo não é enviado para a nuvem.

## O que você precisa fazer no Windows

### 1. Preparar ferramentas

Abra o PowerShell ou Windows Terminal como usuário normal. Não use o modo administrador para esta preparação inicial.

Instale o Rust:

```powershell
winget install Rustlang.Rustup
```

Feche e abra o terminal novamente e confirme:

```powershell
rustc --version
cargo --version
```

Instale o Tauri CLI:

```powershell
cargo install tauri-cli
```

Instale o WebView2 Runtime, caso ainda não esteja instalado:

```powershell
winget install Microsoft.EdgeWebView2Runtime
```

Instale o **Visual Studio Build Tools** com o workload **Desktop development with C++**. Isso é necessário para compilar o executável Windows.

Instale também o CMake, exigido pelo build nativo do llama.cpp:

```powershell
winget install -e --id Kitware.CMake
```

Feche e abra o terminal novamente e confirme:

```powershell
cmake --version
```

Se `cl.exe` não for encontrado, abra o **Developer PowerShell for VS** pelo menu Iniciar antes de executar o Terminalia. Esse terminal configura automaticamente o compilador C++ do Visual Studio.

Como o backend llama.cpp usa `bindgen`, instale também o LLVM, que fornece `libclang.dll`:

```powershell
winget install -e --id LLVM.LLVM
```

Feche e abra o PowerShell novamente. Se o Cargo ainda não localizar a biblioteca, defina o caminho manualmente:

```powershell
$env:LIBCLANG_PATH = "C:\Program Files\LLVM\bin"
[Environment]::SetEnvironmentVariable("LIBCLANG_PATH", "C:\Program Files\LLVM\bin", "User")
Test-Path "$env:LIBCLANG_PATH\libclang.dll"
```

O último comando deve retornar `True`. O script `scripts\check-windows-native.ps1` também faz essa verificação automaticamente:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\check-windows-native.ps1
```

Instale também o Node.js LTS e habilite o pnpm:

```powershell
corepack enable
corepack prepare pnpm@10.4.1 --activate
pnpm --version
```

### 2. Obter o projeto

O preview publicado não é o aplicativo Windows. Você precisa ter uma cópia local desta pasta do projeto no Windows, preservando a estrutura `client/`, `src-tauri/` e `package.json`.

Dentro da pasta do projeto:

```powershell
pnpm install
pnpm check
pnpm build
```

O projeto inclui um `Cargo.toml` na raiz que declara `src-tauri` como workspace. Não remova esse arquivo nem mantenha um `Cargo.toml` antigo na raiz; ele precisa conter apenas a declaração de workspace para que `cargo metadata` não tente interpretar a pasta React como um pacote Rust.

### 3. Abrir o aplicativo Tauri em desenvolvimento

```powershell
pnpm tauri:dev
```

Para testar o backend Vulkan, depois de instalar o Vulkan SDK e os drivers da GPU, use:

```powershell
pnpm tauri:dev:vulkan
```

O modo padrão `pnpm tauri:dev` usa CPU. O Vulkan SDK e as ferramentas C++ são necessários para **compilar** o backend durante o desenvolvimento. Um futuro instalador distribuído do Terminalia deverá incluir os binários/DLLs já compilados; nesse cenário, o usuário final não precisará instalar Rust, Cargo, CMake, Visual Studio ou o Vulkan SDK. Ele ainda precisará manter o driver da GPU atualizado. Se o computador não tiver Vulkan, o modo Automático deverá permanecer em CPU.

Esse comando inicia a interface e a janela nativa. O botão **Verificar ponte** deve mostrar a ponte como disponível somente dentro dessa janela Tauri. No navegador comum, ele permanece desconectado.

### 4. Testar o primeiro comando nativo

No aplicativo Tauri, teste os três roteadores separadamente: `Get-Location` (PowerShell), `ipconfig` (CMD) e `git --version` (executável direto). O Histórico deve registrar o shell usado em cada evento. Um comando fora da allowlist deve ser recusado sem iniciar processo.

Para gerar o instalador:

```powershell
pnpm tauri:build
```

O Tauri deverá produzir artefatos `.msi` e/ou `.exe` em `src-tauri/target/release/bundle/`.

## Arquivos nativos já preparados

- `src-tauri/Cargo.toml`: dependências Rust e Tauri;
- `src-tauri/src/main.rs`: comandos nativos e allowlist inicial;
- `src-tauri/tauri.conf.json`: janela, build e instaladores;
- `src-tauri/capabilities/default.json`: permissões mínimas;
- `client/src/lib/nativeBridge.ts`: adaptador frontend para `invoke`;
- `client/src/pages/Home.tsx`: botão de verificação conectado à ponte, com fallback seguro no preview web.

## Limites de segurança atuais

A ponte não aceita comandos fora da allowlist, não usa privilégios administrativos, não executa comandos concatenados e não concede acesso de escrita. CMD e PowerShell são invocados somente depois da classificação; executáveis diretos são chamados sem shell intermediário. O diretório de trabalho configurável ainda será conectado antes de liberar comandos que alteram arquivos.

## Checklist

- [ ] Rustup instalado
- [ ] `rustc --version` funcionando
- [ ] `cargo --version` funcionando
- [ ] Tauri CLI instalado
- [ ] WebView2 instalado
- [ ] Visual Studio Build Tools com C++ instalado
- [ ] LLVM instalado e `LIBCLANG_PATH` apontando para `libclang.dll`
- [ ] CMake instalado e `cmake --version` funcionando
- [ ] Node.js LTS instalado
- [ ] pnpm instalado
- [ ] Código disponível localmente
- [ ] `pnpm install` concluído
- [ ] `pnpm check` concluído
- [ ] `pnpm build` concluído
- [ ] `pnpm tauri:dev` abre a janela nativa
- [ ] Botão **Verificar ponte** indica conexão nativa
- [ ] `Get-Location` testado via PowerShell sem privilégios
- [ ] `ipconfig` testado via CMD sem privilégios
- [ ] `git --version` testado como executável direto
- [ ] Shell exibido corretamente no Histórico
- [ ] `pnpm tauri:build` gera o instalador
- [ ] Obsidian ativado somente se o usuário desejar usar um Vault

> A preparação acima não instala nada automaticamente pelo Terminalia. Você executa cada etapa manualmente e pode parar se algum instalador apresentar erro.

## Chat, tarefas reais e responsividade

O Chat agora sincroniza o nome do arquivo GGUF selecionado no painel **Modelos GGUF**. A geração llama.cpp é executada em uma thread de trabalho separada para que a janela continue respondendo enquanto o modelo processa. O indicador de geração permanece visível até a resposta chegar.

A intenção de excluir um atalho da Área de Trabalho é reconhecida quando o pedido menciona exclusão/remoção, atalho e Área de Trabalho/Desktop. O Terminalia mostra o alvo identificado e exige quatro etapas de confirmação, incluindo a frase `EU PERMITO ESTE COMANDO`. Somente depois disso a ponte nativa procura um arquivo `.lnk` ou `.url` com o nome informado na Área de Trabalho do usuário. Nenhum outro arquivo é removido por essa operação.

Teste no Windows com um atalho de teste chamado `Terminalia-Teste`:

```text
exclua o atalho "Terminalia-Teste" da minha área de trabalho
```

Cancele nas três primeiras etapas para verificar que nada foi excluído. Para o teste completo, confirme conscientemente a quarta etapa e verifique que somente o atalho `.lnk` ou `.url` correspondente foi removido.

## Núcleo funcional do agente

A versão atual prioriza execução local. O Chat carrega automaticamente o GGUF selecionado antes de gerar texto; se nenhum modelo estiver selecionado ou carregado, a mensagem de erro informa a causa em vez de retornar uma falha genérica.

Pedidos de criação de pasta e arquivo são executados pela ponte nativa dentro do perfil do usuário. Exclusões e instalações via GitHub exigem as quatro etapas de confirmação e a frase `EU PERMITO ESTE COMANDO`. O executor de processos aceita somente ferramentas conhecidas, como `git`, `python`, `node`, `npm`, `pnpm`, `cargo` e `winget`; `git clone` aceita somente URLs HTTPS de `github.com`.

A leitura de páginas pode ser solicitada com uma URL HTTP ou HTTPS, por exemplo:

```text
acesse https://github.com e mostre o conteúdo principal
```

A página é lida localmente pelo Windows e limitada a 200 mil caracteres. Endereços locais como `localhost`, `127.0.0.1` e `0.0.0.0` são recusados.

### Testes funcionais recomendados

Use mensagens como:

```text
crie uma pasta chamada Terminalia-Teste
crie um arquivo chamado Terminalia-Teste.txt
exclua o arquivo Terminalia-Teste.txt
instale este projeto do GitHub https://github.com/usuario/repositorio
acesse https://github.com
```

A exclusão e o clone devem abrir confirmação reforçada. A criação de pasta e arquivo deve apresentar o resultado da ponte nativa.

## Executor geral e agente local

O Terminalia agora permite que o modelo local proponha comandos gerais no formato `ACTION:shell:comando`. O shell pode ser PowerShell, CMD ou executável direto. O comando é classificado antes da execução: ações de leitura podem executar automaticamente; alterações entram em revisão; ações destrutivas, privilegiadas ou classificadas como alto risco entram na confirmação reforçada de quatro etapas. A ponte registra o shell, o comando, o resultado e o código de saída no histórico local.

O Vault Obsidian continua opcional. Quando ativado e configurado, arquivos Markdown do Vault são carregados como contexto local do agente, sem envio para a nuvem. Isso permite manter procedimentos operacionais, instruções de Alma e notas personalizadas. O Terminalia ignora a pasta `.obsidian` e limita o contexto para evitar excesso de memória.

O agente também pode sugerir registrar um procedimento aprendido. A gravação só ocorre quando o usuário pede explicitamente algo como `salve este procedimento no meu Vault`; nesse caso, uma nota Markdown é criada no Vault escolhido.

As métricas são locais e ficam em `localStorage` no registro `terminalia-local-metrics`. Elas contam execuções, autorizações, falhas e distribuição por shell. Nenhuma métrica é enviada para um serviço externo.

## Geração textual direta

O Terminalia usa diretamente o GGUF selecionado pelo backend local Rust/llama.cpp. Não é necessário instalar ou iniciar `llama-server`, e esta versão não oferece análise de imagens ou carregamento de projetores multimodais.

Após atualizar o runtime, inicie com CPU e 0 camadas GPU para separar problemas de template de problemas de aceleração. Envie primeiro `Responda somente com: OK`. Depois envie `Responda em português do Brasil: qual é a capital do Brasil?`. O backend aplica o chat template embutido no GGUF com a abertura da resposta do assistente. Para modelos Gemma cujo parser Jinja não esteja disponível, é aplicado somente o formato Gemma conhecido; para outros modelos, um erro de template é apresentado em vez de uma geração desconexa.

A amostragem padrão é conservadora: temperatura 0.20, top-k 40, top-p 0.90, min-p 0.05 e penalidade de repetição 1.10.
